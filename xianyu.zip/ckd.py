import json
import re
import asyncio
import httpx

async def get_quote(sender_province, sender_city, receiver_province, receiver_city, goods, weight):
    url = "https://keeper.aycorp.cn/p/w/order/preOrderFeeV1"
    headers = {
        "Host": "keeper.aycorp.cn",
        "Connection": "keep-alive",
        "Content-Length": "173",
        "xweb_xhr": "1",
        "Authorization": "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJ1c2VyIiwibG9naW5JZCI6Ind4X3VzZXI6OTY0NTM2MyIsInJuU3RyIjoiNUJnZkVtcTZHdDBoclFnSzNHWTFDOVd1SkFCVzMyVm8ifQ.uDE3Qd599MlcyhW8fi57rM-y3JZyv1vP1KvrGOvVvH8",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 MicroMessenger/7.0.20.1781(0x6700143B) NetType/WIFI MiniProgramEnv/Windows WindowsWechat/WMPF WindowsWechat(0x63090a13) UnifiedPCWindowsWechat(0xf2540512) XWEB/13871",
        "Content-Type": "application/json",
        "Accept": "*/*",
        "Sec-Fetch-Site": "cross-site",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Referer": "https://servicewechat.com/wx27beca8cf26610bd/1/page-frame.html",
        "Accept-Encoding": "gzip",
        "Accept-Language": "zh-CN,zh;q=0.9"
    }
    data = {
        "customerType": "kd",
        "payMethod": 30,
        "goods": goods,
        "weight": weight,
        "packageCount": 1,
        "senderProvince": sender_province,
        "senderCity": sender_city,
        "receiveProvince": receiver_province,
        "receiveCity": receiver_city
    }
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(url, headers=headers, json=data)
            resp.raise_for_status()  # 检查HTTP错误
            return resp.json()
    except httpx.HTTPError as e:
        return {"code": 500, "msg": f"请求错误: {str(e)}", "data": None}
    except json.JSONDecodeError as e:
        return {"code": 500, "msg": f"JSON解析错误: {str(e)}", "data": None}
    except Exception as e:
        return {"code": 500, "msg": f"未知错误: {str(e)}", "data": None}

def extract_xuzhong(price_detail):
    """
    提取续重价格，如"续2.9"或"续3.0"，返回"2.9/kg"格式
    """
    match = re.search(r"续([\d\.]+)", price_detail)
    if match:
        return f"{match.group(1)}/kg"
    else:
        return "-/kg"

def print_quote(data, sender_province, receiver_province, weight):
    print("\n===============")
    print(f"{sender_province}--{receiver_province}----{weight}kg\n")
    for item in data.get("data", {}).get("Y", []):
        name = (item.get("channelName", "") or "")[:8]
        total = item.get("preOrderFee", "") or ""
        price_detail = item.get("price", "") or ""
        xuzhong = extract_xuzhong(price_detail)
        print(f"{name}:共{total}元---超重:{xuzhong}")
    print("\n1.若体积重大于重量按体积计费!")
    print("2.报价非一口价，最终以快递公司计费重量多退少补!")
    print("===============\n")

def split_province_city(address):
    """
    输入如"安徽省合肥市"，返回（安徽省, 合肥市）
    如果只输入省份，则市为空
    """
    # 匹配"省/自治区/直辖市/市/区/县"后面的内容
    match = re.match(r"(.+?(省|自治区|特别行政区|市|区|县))\s*(.*)", address)
    if match:
        province = match.group(1)
        city = match.group(3)
        return province, city
    else:
        # 只输入省份
        return address, ""

async def main():
    while True:
        print("请输入寄件省市（如：安徽省合肥市）：")
        sender_addr = input().strip()
        sender_province, sender_city = split_province_city(sender_addr)

        print("请输入收件省市（如：广东省深圳市）：")
        receiver_addr = input().strip()
        receiver_province, receiver_city = split_province_city(receiver_addr)

        print("请输入物品类型（如：普货，直接回车默认）：")
        goods = input().strip()
        if not goods:
            goods = "普货"

        print("请输入重量（kg，直接回车默认1）：")
        weight_input = input().strip()
        if not weight_input:
            weight = 1
        else:
            weight = float(weight_input)

        print("正在查询，请稍候...\n")
        result = await get_quote(sender_province, sender_city, receiver_province, receiver_city, goods, weight)
        if result.get("code") == 200:
            print_quote(result, sender_province, receiver_province, weight)
        else:
            print("查询失败：", result.get("msg"))
        print("按回车继续查询，按其他键退出。")
        if input() != "":
            break

if __name__ == "__main__":
    asyncio.run(main())