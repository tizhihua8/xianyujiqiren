import time
import os
import re
import sys
import asyncio
import httpx
from loguru import logger
from utils.xianyu_utils import generate_sign


class XianyuApis:
    def __init__(self):
        self.url = 'https://h5api.m.goofish.com/h5/mtop.taobao.idlemessage.pc.login.token/1.0/'
        self.cookies = {}
        self.headers = {
            'accept': 'application/json',
            'accept-language': 'zh-CN,zh;q=0.9',
            'cache-control': 'no-cache',
            'origin': 'https://www.goofish.com',
            'pragma': 'no-cache',
            'priority': 'u=1, i',
            'referer': 'https://www.goofish.com/',
            'sec-ch-ua': '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
        }
        
    def clear_duplicate_cookies(self):
        """清理重复的cookies"""
        # 记录已经添加过的cookie名称
        added_cookies = set()
        new_cookies = {}
        
        # 获取所有cookies的列表，按照添加顺序排序
        cookies_list = list(self.cookies.items())
        # 倒序遍历cookies（最新的通常在后面）
        cookies_list.reverse()
        
        for name, value in cookies_list:
            if name not in added_cookies:
                new_cookies[name] = value
                added_cookies.add(name)
                
        # 替换cookies
        self.cookies = new_cookies
        
        # 更新完cookies后，更新.env文件
        self.update_env_cookies()
        
    def update_env_cookies(self):
        """更新.env文件中的COOKIES_STR"""
        try:
            # 获取当前cookies的字符串形式
            cookie_str = '; '.join([f"{name}={value}" for name, value in self.cookies.items()])
            
            # 读取.env文件
            env_path = os.path.join(os.getcwd(), '.env')
            if not os.path.exists(env_path):
                logger.warning(".env文件不存在，无法更新COOKIES_STR")
                return
                
            with open(env_path, 'r', encoding='utf-8') as f:
                env_content = f.read()
                
            # 使用正则表达式替换COOKIES_STR的值
            if 'COOKIES_STR=' in env_content:
                new_env_content = re.sub(
                    r'COOKIES_STR=.*', 
                    f'COOKIES_STR={cookie_str}',
                    env_content
                )
                
                # 写回.env文件
                with open(env_path, 'w', encoding='utf-8') as f:
                    f.write(new_env_content)
                    
                logger.debug("已更新.env文件中的COOKIES_STR")
            else:
                logger.warning(".env文件中未找到COOKIES_STR配置项")
        except Exception as e:
            logger.warning(f"更新.env文件失败: {str(e)}")
        
    async def hasLogin(self, retry_count=0):
        """调用hasLogin.do接口进行登录状态检查"""
        if retry_count >= 2:
            logger.error("Login检查失败，重试次数过多")
            return False
            
        try:
            url = 'https://passport.goofish.com/newlogin/hasLogin.do'
            params = {
                'appName': 'xianyu',
                'fromSite': '77'
            }
            data = {
                'hid': self.cookies.get('unb', ''),
                'ltl': 'true',
                'appName': 'xianyu',
                'appEntrance': 'web',
                '_csrf_token': self.cookies.get('XSRF-TOKEN', ''),
                'umidToken': '',
                'hsiz': self.cookies.get('cookie2', ''),
                'bizParams': 'taobaoBizLoginFrom=web',
                'mainPage': 'false',
                'isMobile': 'false',
                'lang': 'zh_CN',
                'returnUrl': '',
                'fromSite': '77',
                'isIframe': 'true',
                'documentReferer': 'https://www.goofish.com/',
                'defaultView': 'hasLogin',
                'umidTag': 'SERVER',
                'deviceId': self.cookies.get('cna', '')
            }
            
            async with httpx.AsyncClient(cookies=self.cookies) as client:
                resp = await client.post(url, params=params, data=data, headers=self.headers)
                res_json = resp.json()
                
                # 更新cookies
                for cookie_name, cookie_value in resp.cookies.items():
                    self.cookies[cookie_name] = cookie_value
            
            if res_json.get('content', {}).get('success'):
                logger.debug("Login成功")
                # 清理和更新cookies
                self.clear_duplicate_cookies()
                return True
            else:
                logger.warning(f"Login失败: {res_json}")
                await asyncio.sleep(0.5)
                return await self.hasLogin(retry_count + 1)
                
        except Exception as e:
            logger.error(f"Login请求异常: {str(e)}")
            await asyncio.sleep(0.5)
            return await self.hasLogin(retry_count + 1)

    async def get_token(self, device_id, retry_count=0):
        if retry_count >= 2:  # 最多重试3次
            logger.warning("获取token失败，尝试重新登陆")
            # 尝试通过hasLogin重新登录
            if await self.hasLogin():
                logger.info("重新登录成功，重新尝试获取token")
                return await self.get_token(device_id, 0)  # 重置重试次数
            else:
                logger.error("重新登录失败，Cookie已失效")
                logger.error("🔴 程序即将退出，请更新.env文件中的COOKIES_STR后重新启动")
                sys.exit(1)  # 直接退出程序
            
        params = {
            'jsv': '2.7.2',
            'appKey': '34839810',
            't': str(int(time.time()) * 1000),
            'sign': '',
            'v': '1.0',
            'type': 'originaljson',
            'accountSite': 'xianyu',
            'dataType': 'json',
            'timeout': '20000',
            'api': 'mtop.taobao.idlemessage.pc.login.token',
            'sessionOption': 'AutoLoginOnly',
            'spm_cnt': 'a21ybx.im.0.0',
        }
        data_val = '{"appKey":"444e9908a51d1cb236a27862abc769c9","deviceId":"' + device_id + '"}'
        data = {
            'data': data_val,
        }
        
        # 简单获取token，信任cookies已清理干净
        token = self.cookies.get('_m_h5_tk', '').split('_')[0] if '_m_h5_tk' in self.cookies else ''
        
        sign = generate_sign(params['t'], token, data_val)
        params['sign'] = sign
        
        try:
            async with httpx.AsyncClient(cookies=self.cookies) as client:
                resp = await client.post('https://h5api.m.goofish.com/h5/mtop.taobao.idlemessage.pc.login.token/1.0/', 
                                      params=params, data=data, headers=self.headers)
                res_json = resp.json()
                
                # 更新cookies
                for cookie_name, cookie_value in resp.cookies.items():
                    self.cookies[cookie_name] = cookie_value
            
            if isinstance(res_json, dict):
                ret_value = res_json.get('ret', [])
                # 检查ret是否包含成功信息
                if not any('SUCCESS::调用成功' in ret for ret in ret_value):
                    logger.warning(f"Token API调用失败，错误信息: {ret_value}")
                    # 更新完cookie之后清理重复
                    self.clear_duplicate_cookies()
                    await asyncio.sleep(0.5)
                    return await self.get_token(device_id, retry_count + 1)
                else:
                    logger.info("Token获取成功")
                    return res_json
            else:
                logger.error(f"Token API返回格式异常: {res_json}")
                return await self.get_token(device_id, retry_count + 1)
                
        except Exception as e:
            logger.error(f"Token API请求异常: {str(e)}")
            await asyncio.sleep(0.5)
            return await self.get_token(device_id, retry_count + 1)

    async def get_item_info(self, item_id, retry_count=0):
        """获取商品信息，自动处理token失效的情况"""
        if retry_count >= 3:  # 最多重试3次
            logger.error("获取商品信息失败，重试次数过多")
            return {"error": "获取商品信息失败，重试次数过多"}
            
        params = {
            'jsv': '2.7.2',
            'appKey': '34839810',
            't': str(int(time.time()) * 1000),
            'sign': '',
            'v': '1.0',
            'type': 'originaljson',
            'accountSite': 'xianyu',
            'dataType': 'json',
            'timeout': '20000',
            'api': 'mtop.taobao.idle.pc.detail',
            'sessionOption': 'AutoLoginOnly',
            'spm_cnt': 'a21ybx.im.0.0',
        }
        
        data_val = '{"itemId":"' + item_id + '"}'
        data = {
            'data': data_val,
        }
        
        # 简单获取token，信任cookies已清理干净
        token = self.cookies.get('_m_h5_tk', '').split('_')[0] if '_m_h5_tk' in self.cookies else ''
        
        sign = generate_sign(params['t'], token, data_val)
        params['sign'] = sign
        
        try:
            async with httpx.AsyncClient(cookies=self.cookies) as client:
                resp = await client.post('https://h5api.m.goofish.com/h5/mtop.taobao.idle.pc.detail/1.0/', 
                                      params=params, data=data, headers=self.headers)
                res_json = resp.json()
                
                # 更新cookies
                for cookie_name, cookie_value in resp.cookies.items():
                    self.cookies[cookie_name] = cookie_value
            
            # 检查返回状态
            if isinstance(res_json, dict):
                ret_value = res_json.get('ret', [])
                # 检查ret是否包含成功信息
                if not any('SUCCESS::调用成功' in ret for ret in ret_value):
                    logger.warning(f"商品信息API调用失败，错误信息: {ret_value}")
                    # 处理可能的token失效
                    if any('令牌过期' in ret for ret in ret_value):
                        logger.debug("令牌过期，尝试重新获取token")
                        # 尝试重新获取token
                        device_id = self.cookies.get('cna', '')
                        token_result = await self.get_token(device_id)
                        if token_result and any('SUCCESS::调用成功' in ret for ret in token_result.get('ret', [])):
                            # token获取成功，重新尝试获取商品信息
                            logger.debug("令牌刷新成功，重新获取商品信息")
                            return await self.get_item_info(item_id, 0)  # 重置重试计数
                    
                    await asyncio.sleep(0.5)
                    return await self.get_item_info(item_id, retry_count + 1)
                else:
                    # 返回商品数据
                    return res_json
            else:
                logger.error(f"商品信息API返回格式异常: {res_json}")
                return await self.get_item_info(item_id, retry_count + 1)
        
        except Exception as e:
            logger.error(f"商品信息API请求异常: {str(e)}")
            await asyncio.sleep(0.5)
            return await self.get_item_info(item_id, retry_count + 1)
