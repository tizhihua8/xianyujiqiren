import asyncio
import json
from XianyuAgent import XianyuReplyBot
from XianyuApis import XianyuApis

async def get_item_info(item_id):
    """获取商品信息"""
    api = XianyuApis()
    try:
        result = await api.get_item_info(item_id)
        if isinstance(result, dict) and 'data' in result:
            data = result['data']
            if isinstance(data, dict) and 'itemDO' in data:
                item_info = data['itemDO']
                if isinstance(item_info, dict):
                    desc = item_info.get('desc', '无描述')
                    price = item_info.get('soldPrice', '0')
                    title = item_info.get('title', '无标题')
                    item_description = f"{desc};当前商品售卖价格为:{str(price)}"
                    print(f"成功获取商品信息: {title}, 价格: {price}")
                    return item_description
        print(f"获取商品信息失败: {result}")
    except Exception as e:
        print(f"获取商品信息出错: {e}")
    return None

async def main():
    print("闲鱼客服机器人测试程序")
    print("命令：'reset'重置会话，'exit'退出")
    
    # 初始化机器人（只初始化一次）
    bot = XianyuReplyBot()
    
    # 检查是否使用百炼应用API
    is_dashscope_app = bot.config.get("provider_type", "") == "dashscope_app"
    if is_dashscope_app:
        print("当前使用百炼应用API模式")
    
    # 获取商品ID
    item_id = input("请输入商品ID: ")
    
    # 获取商品信息
    item_desc = await get_item_info(item_id)
    if not item_desc:
        item_desc = input("无法获取商品信息，请手动输入商品描述: ")
    
    # 对话上下文（保持在整个对话过程中）
    context = [
        {"role": "system", "content": f"你是一个闲鱼客服机器人。商品描述：{item_desc}"}
    ]
    
    # 进入对话循环
    while True:
        # 用户输入
        user_msg = input("\n你：")
        
        # 检查是否退出
        if user_msg.lower() in ['exit', 'quit', '退出']:
            print("已退出对话")
            break
            
        # 检查是否重置会话
        if user_msg.lower() == 'reset':
            context = [
                {"role": "system", "content": f"你是一个闲鱼客服机器人。商品描述：{item_desc}"}
            ]
            # 安全地尝试重置会话
            try:
                if is_dashscope_app and hasattr(bot.provider, "reset_session"):
                    bot.provider.reset_session()
            except Exception as e:
                print(f"重置会话出错: {e}")
            print("已重置会话")
            continue
            
        # 过滤系统日志类输入
        if user_msg.startswith("20") and "|" in user_msg[:30]:
            print("请勿输入系统日志")
            continue
        
        # 添加用户消息到上下文
        context.append({"role": "user", "content": user_msg})
        
        # 生成回复
        reply = bot.generate_reply(user_msg, item_desc, context)
        print(f"机器人: {reply}")
        
        # 添加回复到上下文
        context.append({"role": "assistant", "content": reply})

if __name__ == "__main__":
    asyncio.run(main()) 