"""
回退提供商模块

提供一个简单的回退提供商，当providers包不可用时使用。
"""
from typing import List, Dict, Any
from abc import ABC, abstractmethod
import requests
from loguru import logger


class LLMProvider(ABC):
    """LLM提供商抽象基类"""
    
    @abstractmethod
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.4, max_tokens: int = 500, **kwargs) -> str:
        """调用模型生成回复"""
        pass
    
    @property
    @abstractmethod
    def provider_name(self) -> str:
        """获取提供商名称"""
        pass


class FallbackProvider(LLMProvider):
    """回退提供商，当无法使用主要提供商时使用"""
    
    def __init__(self):
        logger.warning("使用回退提供商，直接使用规则匹配")
        
    @property
    def provider_name(self) -> str:
        return "fallback"
    
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.4, max_tokens: int = 500, **kwargs) -> str:
        """回退提供商的消息处理方式，不需要调用API，直接用规则生成回复"""
        try:
            # 尝试提取最后一条用户消息
            user_message = ""
            for msg in reversed(messages):
                if msg.get("role") == "user" and msg.get("content"):
                    user_message = msg["content"]
                    break
            
            # 如果没找到用户消息，返回错误提示
            if not user_message:
                return "无法处理空消息"
                
            # 简单的规则匹配，根据关键词返回一些基本回复
            if "价格" in user_message or "多少钱" in user_message or "优惠" in user_message or "便宜" in user_message:
                return "您好，关于价格问题，我们可以适当商量，请告诉我您的预算是多少？"
            elif "发货" in user_message or "物流" in user_message or "快递" in user_message:
                return "我们会在付款后24小时内发货，快递一般3-5天送达，具体情况视物流公司而定。"
            elif "质量" in user_message or "品质" in user_message or "保修" in user_message:
                return "产品质量有保证，支持7天无理由退换，一年保修服务。"
            elif "广州" in user_message and "上海" in user_message:
                return "广州到上海的快递费用大约是20元左右，具体费用视包裹重量和快递公司而定。"
            else:
                return "感谢您的咨询，请问您对商品还有什么具体问题需要了解的吗？"
                
        except Exception as e:
            logger.error(f"回退提供商处理消息失败: {e}")
            return "抱歉，系统暂时无法处理您的请求，请稍后再试。" 