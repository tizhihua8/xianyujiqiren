"""
OpenAI兼容格式API提供商模块

提供与OpenAI兼容格式API交互的功能，包括：
1. OpenAI官方API
2. 阿里云通义千问模型API (dashscope)
3. 其他使用OpenAI兼容格式的API服务
"""
from typing import List, Dict, Optional
from loguru import logger

from providers.base import LLMProvider

# 尝试导入OpenAI
HAS_OPENAI = False
try:
    from openai import OpenAI
    from openai.types.chat import ChatCompletionMessageParam
    HAS_OPENAI = True
except ImportError:
    logger.warning("未找到openai模块，OpenAI兼容模式将不可用")


class OpenAIProvider(LLMProvider):
    """OpenAI兼容格式API提供商"""
    
    def __init__(self, api_key: str, base_url: str, model_name: str):
        """初始化OpenAI兼容格式提供商
        
        Args:
            api_key: API密钥
            base_url: API基础URL
            model_name: 使用的模型名称
        """
        if not HAS_OPENAI:
            raise ImportError("请先安装openai库: pip install openai")
            
        self.client = OpenAI(
            api_key=api_key,
            base_url=base_url,
        )
        self.model_name = model_name
        self._session_id = None
        
        # 根据base_url判断使用的是哪种具体服务
        if "api.openai.com" in base_url:
            self._provider_subtype = "openai"
        elif "dashscope" in base_url:
            self._provider_subtype = "dashscope"
        else:
            self._provider_subtype = "openai_compatible"
            
        logger.info(f"使用OpenAI兼容格式API: {self._provider_subtype}, 模型: {model_name}")
    
    @property
    def provider_name(self) -> str:
        return self._provider_subtype
    
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.4, max_tokens: int = 500, **kwargs) -> str:
        """使用OpenAI兼容接口调用模型"""
        extra_body = kwargs.get("extra_body", {})
        
        # 转换为OpenAI支持的消息格式
        openai_messages = []
        for msg in messages:
            if 'role' in msg and 'content' in msg:
                # 创建符合OpenAI格式的消息
                openai_messages.append({
                    "role": msg["role"],
                    "content": msg["content"]
                })
        
        try:
            # 调用API
            logger.debug(f"调用{self._provider_subtype} API，模型: {self.model_name}")
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=openai_messages,
                temperature=temperature,
                max_tokens=max_tokens,
                top_p=0.8,
                **extra_body
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"{self._provider_subtype} API调用失败: {e}")
            return f"模型调用出错，请稍后再试。错误: {str(e)[:100]}" 