"""
提供商包

该包提供了与不同LLM服务商交互的接口实现。
"""
from typing import Dict, Any, Optional

from providers.base import LLMProvider
from providers.factory import create_provider

# 尝试导入各种提供商，但不强制要求
try:
    from providers.openai_provider import OpenAIProvider
except ImportError:
    pass

try:
    from providers.dashscope_app_provider import DashscopeAppProvider
except ImportError:
    pass

try:
    from providers.custom_http_provider import CustomHTTPProvider
except ImportError:
    pass

try:
    from providers.chutes_provider import ChutesProvider
except ImportError:
    pass

__all__ = [
    'LLMProvider',
    'create_provider',
    'OpenAIProvider',
    'DashscopeAppProvider',
    'CustomHTTPProvider',
    'ChutesProvider',
]

# 版本信息
__version__ = '0.2.0' 