"""
Chutes提供商模块

提供与Chutes AI API交互的功能，支持流式输出。
"""
import json
import asyncio
from typing import List, Dict, Optional, Any, AsyncGenerator
import aiohttp
from loguru import logger

from providers.base import LLMProvider


class ChutesProvider(LLMProvider):
    """Chutes AI API提供商"""
    
    def __init__(self, api_key: str, api_url: str = "https://llm.chutes.ai/v1/chat/completions", model: str = "deepseek-ai/DeepSeek-R1"):
        """初始化Chutes提供商
        
        Args:
            api_key: API密钥
            api_url: API接口URL，默认为Chutes AI的接口
            model: 模型名称，默认为DeepSeek-R1
        """
        self.api_key = api_key
        self.api_url = api_url
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        # 设置模型
        self.model = model
        logger.info(f"初始化Chutes提供商，使用模型: {model}")
    
    @property
    def provider_name(self) -> str:
        return "chutes"
    
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.7, max_tokens: int = 1024, **kwargs) -> str:
        """使用Chutes API调用模型
        
        这是同步版本的API调用，但会安全地处理已有事件循环的情况
        """
        # 检查是否已在事件循环中
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # 如果已经在事件循环中，使用同步HTTP请求
                return self._sync_chat_completion(messages, temperature, max_tokens, **kwargs)
            else:
                # 如果有事件循环但没有运行，使用它
                return loop.run_until_complete(self._async_chat_completion(messages, temperature, max_tokens, **kwargs))
        except RuntimeError:
            # 如果没有事件循环，创建一个新的
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            return loop.run_until_complete(self._async_chat_completion(messages, temperature, max_tokens, **kwargs))
    
    def _sync_chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.7, max_tokens: int = 1024, **kwargs) -> str:
        """同步版本的API调用，使用requests库
        
        用于在已有事件循环运行时调用
        """
        import requests
        
        # 获取模型参数，优先使用kwargs中的model，其次使用实例的model属性
        model = kwargs.get("model", self.model)
        
        # 构建请求体
        payload = {
            "model": model,
            "messages": messages,
            "stream": False,  # 同步请求不使用流式输出
            "max_tokens": max_tokens,
            "temperature": temperature
        }
        
        # 合并其他参数
        extra_params = kwargs.get("extra_params", {})
        if extra_params and isinstance(extra_params, dict):
            payload.update(extra_params)
        
        try:
            response = requests.post(
                self.api_url,
                headers=self.headers,
                json=payload,
                timeout=60  # 设置超时时间
            )
            
            if response.status_code != 200:
                logger.error(f"Chutes API调用失败: 状态码 {response.status_code}, 错误: {response.text}")
                return f"模型调用出错，状态码: {response.status_code}。请稍后再试。"
            
            # 解析响应
            result = response.json()
            if "choices" in result and len(result["choices"]) > 0:
                if "message" in result["choices"][0] and "content" in result["choices"][0]["message"]:
                    return result["choices"][0]["message"]["content"]
            
            logger.error(f"无法解析Chutes API响应: {result}")
            return "无法解析模型响应，请稍后再试。"
        except Exception as e:
            logger.error(f"Chutes API调用异常: {e}")
            return f"模型调用出错: {str(e)[:100]}。请稍后再试。"
    
    async def _async_chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.7, max_tokens: int = 1024, **kwargs) -> str:
        """异步调用Chutes API
        
        Args:
            messages: 对话消息列表
            temperature: 温度参数
            max_tokens: 最大生成token数
            **kwargs: 其他参数
            
        Returns:
            str: 完整的生成文本
        """
        # 获取模型参数，优先使用kwargs中的model，其次使用实例的model属性
        model = kwargs.get("model", self.model)
        
        # 构建请求体
        payload = {
            "model": model,
            "messages": messages,
            "stream": True,  # 使用流式输出
            "max_tokens": max_tokens,
            "temperature": temperature
        }
        
        # 合并其他参数
        extra_params = kwargs.get("extra_params", {})
        if extra_params and isinstance(extra_params, dict):
            payload.update(extra_params)
        
        full_response = ""
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.api_url, 
                    headers=self.headers,
                    json=payload
                ) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        logger.error(f"Chutes API调用失败: 状态码 {response.status}, 错误: {error_text}")
                        return f"模型调用出错，状态码: {response.status}。请稍后再试。"
                    
                    # 处理流式响应
                    async for line in response.content:
                        line = line.decode("utf-8").strip()
                        if line.startswith("data: "):
                            data = line[6:]
                            if data == "[DONE]":
                                break
                            try:
                                chunk_data = json.loads(data)
                                if "choices" in chunk_data and len(chunk_data["choices"]) > 0:
                                    delta = chunk_data["choices"][0].get("delta", {})
                                    if "content" in delta:
                                        content = delta["content"]
                                        full_response += content
                            except Exception as e:
                                logger.error(f"解析Chutes响应块失败: {e}")
                                continue
        except Exception as e:
            logger.error(f"Chutes API调用异常: {e}")
            return f"模型调用出错: {str(e)[:100]}。请稍后再试。"
        
        return full_response
    
    async def stream_chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.7, max_tokens: int = 1024, **kwargs) -> AsyncGenerator[str, None]:
        """流式调用Chutes API
        
        Args:
            messages: 对话消息列表
            temperature: 温度参数
            max_tokens: 最大生成token数
            **kwargs: 其他参数
            
        Yields:
            str: 生成的文本块
        """
        # 获取模型参数，优先使用kwargs中的model，其次使用实例的model属性
        model = kwargs.get("model", self.model)
        
        # 构建请求体
        payload = {
            "model": model,
            "messages": messages,
            "stream": True,  # 使用流式输出
            "max_tokens": max_tokens,
            "temperature": temperature
        }
        
        # 合并其他参数
        extra_params = kwargs.get("extra_params", {})
        if extra_params and isinstance(extra_params, dict):
            payload.update(extra_params)
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    self.api_url, 
                    headers=self.headers,
                    json=payload
                ) as response:
                    if response.status != 200:
                        error_text = await response.text()
                        logger.error(f"Chutes API调用失败: 状态码 {response.status}, 错误: {error_text}")
                        yield f"模型调用出错，状态码: {response.status}。请稍后再试。"
                        return
                    
                    # 处理流式响应
                    async for line in response.content:
                        line = line.decode("utf-8").strip()
                        if line.startswith("data: "):
                            data = line[6:]
                            if data == "[DONE]":
                                break
                            try:
                                chunk_data = json.loads(data)
                                if "choices" in chunk_data and len(chunk_data["choices"]) > 0:
                                    delta = chunk_data["choices"][0].get("delta", {})
                                    if "content" in delta:
                                        content = delta["content"]
                                        yield content
                            except Exception as e:
                                logger.error(f"解析Chutes响应块失败: {e}")
                                continue
        except Exception as e:
            logger.error(f"Chutes API调用异常: {e}")
            yield f"模型调用出错: {str(e)[:100]}。请稍后再试。" 