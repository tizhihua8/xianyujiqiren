"""
提供商基类模块

定义与AI服务商交互的基本接口。
"""
from abc import ABC, abstractmethod
from typing import List, Dict, Any


class LLMProvider(ABC):
    """LLM提供商抽象基类
    
    所有模型提供商必须实现的接口。定义了与大语言模型交互的标准方法。
    """
    
    @abstractmethod
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.4, max_tokens: int = 500, **kwargs) -> str:
        """调用模型生成回复
        
        Args:
            messages: 对话消息列表，格式为[{"role": "user", "content": "消息内容"}, ...]
            temperature: 温度参数，控制生成内容的随机性，范围通常为0-1
            max_tokens: 生成内容的最大token数
            **kwargs: 额外参数
            
        Returns:
            str: 模型生成的回复文本
        """
        pass
    
    @property
    @abstractmethod
    def provider_name(self) -> str:
        """获取提供商名称
        
        Returns:
            str: 提供商名称，用于标识和日志记录
        """
        pass 