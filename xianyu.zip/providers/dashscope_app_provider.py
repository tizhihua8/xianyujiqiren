"""
百炼应用提供商模块

提供与阿里云百炼应用API交互的功能。
注意：百炼应用使用的是Application.call()方法，无需指定API URL，它已在dashscope库中内置。
"""
from typing import List, Dict, Any, Optional
from http import HTTPStatus
from loguru import logger

from providers.base import LLMProvider

# 尝试导入百炼应用
HAS_DASHSCOPE_APP = False
try:
    from dashscope import Application
    HAS_DASHSCOPE_APP = True
except ImportError:
    logger.warning("未找到dashscope.Application模块，百炼应用功能将受限")


class DashscopeAppProvider(LLMProvider):
    """阿里云百炼应用API提供商"""
    
    def __init__(self, api_key: str, app_id: str):
        """初始化百炼应用提供商
        
        Args:
            api_key: 阿里云API密钥
            app_id: 百炼应用ID
        """
        if not HAS_DASHSCOPE_APP:
            raise ImportError("请先安装dashscope库: pip install dashscope")
        
        self.api_key = api_key
        self.app_id = app_id
        self._session_id = None  # 保存会话ID
        logger.info(f"初始化通义千问应用提供商，应用ID: {app_id}")
    
    @property
    def provider_name(self) -> str:
        return "dashscope_app"
    
    def reset_session(self):
        """重置会话，清除会话ID"""
        self._session_id = None
        logger.info(f"已重置百炼应用会话")
    
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.4, max_tokens: int = 500, **kwargs) -> str:
        """使用百炼应用接口调用模型
        
        注意：百炼应用API只需要最新的用户消息和会话ID，不需要传递整个对话历史
        无需指定API URL，直接使用Application.call()方法
        """
        try:
            # 获取最新的用户消息
            user_message = ""
            for msg in reversed(messages):
                if msg.get("role") == "user" and msg.get("content"):
                    user_message = msg["content"]
                    break
                    
            if not user_message:
                return "未找到用户消息"
                
            # 过滤掉可能是系统日志的消息
            if user_message.startswith("20") and "|" in user_message[:30]:
                return "请输入商品咨询，而不是系统日志"
            
            # 截断过长的消息
            if len(user_message) > 500:
                user_message = user_message[:497] + "..."
                logger.debug("用户消息过长，已截断")
            
            # 构建调用参数 - 注意百炼应用API只需要这几个参数
            call_params = {
                "api_key": self.api_key,
                "app_id": self.app_id,
                "prompt": user_message  # 百炼应用只需要发送最新的用户消息
            }
            
            # 如果有会话ID，添加到请求中以维持上下文
            if self._session_id:
                call_params["session_id"] = self._session_id
                logger.debug(f"使用已有会话ID: {self._session_id}")
                
            # 调用百炼应用 - 无需指定URL，直接使用Application.call()
            logger.debug(f"调用百炼应用 {self.app_id}, 消息: {user_message[:20]}...")
            response = None
            try:
                # 直接调用Application.call方法，该方法内部已指定了API URL
                response = Application.call(**call_params)
                
                # 检查状态码
                if hasattr(response, "status_code") and response.status_code != HTTPStatus.OK:
                    error_msg = f"请求失败：状态码 {response.status_code}"
                    if hasattr(response, "message"):
                        error_msg += f", 消息: {response.message}"
                    if hasattr(response, "request_id"):
                        error_msg += f", 请求ID: {response.request_id}"
                    logger.error(error_msg)
                    return f"调用应用失败: {error_msg}"
            except Exception as e:
                logger.error(f"调用Application.call时出错: {str(e)}")
                return f"应用调用出错: {str(e)[:100]}"
            
            # 解析响应，提取文本回复和会话ID
            result = ""
            new_session_id = None
            
            # 检查响应是否有效
            if not response:
                return "应用响应为空"
                
            # 尝试提取响应内容和会话ID
            try:
                if hasattr(response, "output"):
                    # 对象式响应
                    output = response.output
                    if hasattr(output, "text"):
                        result = output.text
                    if hasattr(output, "session_id"):
                        new_session_id = output.session_id
                elif isinstance(response, dict) and "output" in response:
                    # 字典式响应
                    output = response["output"]
                    if isinstance(output, dict):
                        if "text" in output:
                            result = output["text"]
                        if "session_id" in output:
                            new_session_id = output["session_id"]
            except Exception as e:
                logger.error(f"解析响应时出错: {str(e)}")
                
            # 保存新的会话ID，用于下一次请求
            if new_session_id:
                self._session_id = new_session_id
                logger.debug(f"更新会话ID为: {new_session_id}")
            
            # 返回结果
            if result:
                return result
            else:
                logger.error(f"无法从应用响应中提取文本: {response}")
                return "应用未返回有效回复"
                
        except Exception as e:
            logger.error(f"百炼应用调用过程中出错: {e}")
            return f"应用调用出错，请稍后再试。错误: {str(e)[:100]}" 