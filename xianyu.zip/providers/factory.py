"""
提供商工厂模块

用于创建不同类型的LLM提供商实例。主要分为四类：
1. OpenAI格式API (openai): 兼容OpenAI接口格式的API，包括OpenAI自身和其他兼容格式
2. DashScope应用API (dashscope): 阿里云通义千问的应用接口
3. Chutes API (chutes): Chutes AI的流式输出接口
4. 自定义HTTP接口 (custom): 其他自定义HTTP接口
"""
import os
from typing import Dict, Any, Optional
from loguru import logger

# 导入基类
from providers.base import LLMProvider

# 导入可选的提供商
try:
    from providers.openai_provider import OpenAIProvider, HAS_OPENAI
except ImportError:
    HAS_OPENAI = False
    
try:
    from providers.dashscope_app_provider import DashscopeAppProvider, HAS_DASHSCOPE_APP
except ImportError:
    HAS_DASHSCOPE_APP = False

try:
    from providers.chutes_provider import ChutesProvider
    HAS_CHUTES = True
except ImportError:
    HAS_CHUTES = False

# 总是导入HTTP提供商作为回退选项
from providers.custom_http_provider import CustomHTTPProvider


def create_provider(config: Dict[str, Any]) -> LLMProvider:
    """
    根据配置创建合适的LLM提供商实例
    
    Args:
        config: 配置字典，必须包含provider_type字段
        
    Returns:
        LLMProvider: 创建的提供商实例
    """
    # 获取环境变量或配置文件中的provider_type
    provider_type = config.get("provider_type", "").lower() or os.getenv("PROVIDER_TYPE", "").lower()
    
    if not provider_type:
        logger.warning("未指定provider_type，使用openai作为默认值")
        provider_type = "openai"
    
    # 输出使用的配置来源
    env_file = os.path.exists(".env")
    if env_file:
        logger.info(f"使用.env文件中的配置，提供商类型: {provider_type}")
    else:
        logger.info(f"使用config.json文件中的配置，提供商类型: {provider_type}")
    
    # 获取通用配置项 - API密钥
    api_key = str(config.get("api_key") or os.getenv("API_KEY", ""))
    if not api_key:
        logger.error("未提供API密钥，无法调用API")
        from providers_fallback import FallbackProvider
        return FallbackProvider()
    
    # 根据provider_type创建不同的提供商
    if provider_type == "openai":
        # OpenAI官方API
        if not HAS_OPENAI:
            logger.error("未安装openai模块，无法使用OpenAI API")
            return _fallback_provider(api_key)
            
        model = str(config.get("openai_model") or os.getenv("OPENAI_MODEL", "gpt-3.5-turbo"))
        base_url = str(config.get("openai_url") or os.getenv("OPENAI_URL", "https://api.openai.com/v1"))
        
        return OpenAIProvider(
            api_key=api_key,
            base_url=base_url,
            model_name=model
        )
    elif provider_type in ["dashscope", "dashscope_model"]:
        # 阿里云通义千问模型API
        if not HAS_OPENAI:
            logger.error("未安装openai模块，无法使用通义千问模型API")
            return _fallback_provider(api_key)
            
        model = str(config.get("dashscope_model") or os.getenv("DASHSCOPE_MODEL", "qwen-max"))
        base_url = str(config.get("dashscope_url") or os.getenv("DASHSCOPE_URL", "https://dashscope.aliyuncs.com/v1"))
        
        return OpenAIProvider(
            api_key=api_key,
            base_url=base_url,
            model_name=model
        )
    elif provider_type == "dashscope_app":
        # 阿里云通义千问应用API
        if not HAS_DASHSCOPE_APP:
            logger.error("未安装dashscope模块，无法使用通义千问应用API")
            return _fallback_provider(api_key)
        
        app_id = str(config.get("app_id") or os.getenv("APP_ID", ""))
        if not app_id:
            logger.error("未提供应用ID (APP_ID)，无法使用通义千问应用API")
            return _fallback_provider(api_key)
            
        # 注意：阿里云应用API无需指定URL，内部已设置
        return DashscopeAppProvider(
            api_key=api_key,
            app_id=app_id
        )
    elif provider_type == "chutes":
        # Chutes AI API
        if not HAS_CHUTES:
            logger.error("未正确导入Chutes提供商，无法使用Chutes API")
            return _fallback_provider(api_key)
            
        # 按照优先级查找配置：
        # 1. CHUTES_URL/CHUTES_MODEL
        # 2. CUSTOM_PROVIDER1_URL/CUSTOM_PROVIDER1_MODEL (兼容旧配置)
        # 3. 默认值
        api_url = str(config.get("chutes_url") or os.getenv("CHUTES_URL") or os.getenv("CUSTOM_PROVIDER1_URL", "https://llm.chutes.ai/v1/chat/completions"))
        model = str(config.get("chutes_model") or os.getenv("CHUTES_MODEL") or os.getenv("CUSTOM_PROVIDER1_MODEL", "deepseek-ai/DeepSeek-R1"))
        
        logger.info(f"使用Chutes API，URL: {api_url}, 模型: {model}")
        
        provider = ChutesProvider(
            api_key=api_key,
            api_url=api_url,
            model=model
        )
        return provider
    elif provider_type in ["custom", "http"]:
        # 默认自定义HTTP接口
        api_url = str(config.get("custom_url") or os.getenv("CUSTOM_URL", ""))
        if not api_url:
            logger.error("未提供自定义接口URL (CUSTOM_URL)，无法使用自定义HTTP接口")
            return _fallback_provider(api_key)
        
        model = str(config.get("custom_model") or os.getenv("CUSTOM_MODEL", ""))
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
        
        return CustomHTTPProvider(
            api_url=api_url,
            headers=headers,
            provider_type="custom"
        )
    elif provider_type.startswith("custom_"):
        # 其他自定义HTTP接口
        provider_name = provider_type.upper()  # 例如：custom_1 -> CUSTOM_1
        url_key = f"{provider_name}_URL"
        model_key = f"{provider_name}_MODEL"
        
        api_url = str(config.get(url_key.lower()) or os.getenv(url_key, ""))
        if not api_url:
            logger.error(f"未提供{provider_name}接口URL ({url_key})，无法使用该自定义HTTP接口")
            return _fallback_provider(api_key)
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
        
        return CustomHTTPProvider(
            api_url=api_url,
            headers=headers,
            provider_type=provider_type
        )
    else:
        logger.error(f"不支持的提供商类型: {provider_type}，使用默认HTTP模式")
        return _fallback_provider(api_key)


def _fallback_provider(api_key: str) -> CustomHTTPProvider:
    """创建默认的回退HTTP提供商"""
    logger.info("回退到默认HTTP模式")
    return CustomHTTPProvider(
        api_url="https://api.openai.com/v1/chat/completions",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        }
    ) 