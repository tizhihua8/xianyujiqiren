"""
自定义HTTP提供商模块

提供与自定义HTTP接口交互的功能。
"""
from typing import List, Dict, Optional, Any
import requests
from loguru import logger

from providers.base import LLMProvider


class CustomHTTPProvider(LLMProvider):
    """自定义HTTP接口提供商"""
    
    def __init__(self, api_url: str, headers: Optional[Dict[str, str]] = None, provider_type: str = "custom"):
        """初始化自定义HTTP提供商
        
        Args:
            api_url: API接口URL
            headers: 请求头信息
            provider_type: 提供商类型标识
        """
        self.api_url = api_url
        self.headers = headers or {"Content-Type": "application/json"}
        self._provider_type = provider_type  # 自定义提供商类型名称
    
    @property
    def provider_name(self) -> str:
        return self._provider_type
    
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.4, max_tokens: int = 500, **kwargs) -> str:
        """使用自定义HTTP接口调用模型"""
        payload = {
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "top_p": 0.8,
        }
        
        # 合并其他参数
        extra_params = kwargs.get("extra_params", {})
        if extra_params and isinstance(extra_params, dict):
            payload.update(extra_params)
        
        try:
            response = requests.post(self.api_url, headers=self.headers, json=payload)
            response.raise_for_status()
            
            # 解析返回结果
            result = response.json()
            
            # 灵活处理不同格式的返回结果
            return self._extract_content(result)
        except Exception as e:
            logger.error(f"HTTP接口调用失败: {e}")
            return f"模型调用出错，请稍后再试。错误: {str(e)[:100]}"
    
    def _extract_content(self, result: Dict[str, Any]) -> str:
        """从不同格式的返回结果中提取内容
        
        支持的格式:
        1. OpenAI格式: {"choices": [{"message": {"content": "回复内容"}}]}
        2. 百炼格式: {"output": {"text": "回复内容"}}
        3. 简单格式: {"response": "回复内容"}
        
        Args:
            result: API返回的JSON结果
            
        Returns:
            str: 提取的内容文本
        """
        # OpenAI格式
        if "choices" in result and len(result["choices"]) > 0:
            if "message" in result["choices"][0] and "content" in result["choices"][0]["message"]:
                return result["choices"][0]["message"]["content"]
            elif "text" in result["choices"][0]:
                return result["choices"][0]["text"]
        
        # 百炼格式
        elif "output" in result:
            if isinstance(result["output"], dict):
                if "text" in result["output"]:
                    return result["output"]["text"]
                elif "choices" in result["output"] and len(result["output"]["choices"]) > 0:
                    if "message" in result["output"]["choices"][0] and "content" in result["output"]["choices"][0]["message"]:
                        return result["output"]["choices"][0]["message"]["content"]
        
        # 简单格式
        elif "response" in result:
            return str(result["response"])
        
        # 找不到支持的格式
        logger.error(f"未知的HTTP接口返回格式: {result}")
        return "接口返回格式不支持，请联系管理员" 