"""
配置管理器 - 用于加载和使用配置文件
"""
import os
import json
from typing import Dict, Any, List, Optional
from loguru import logger

class ConfigManager:
    """配置管理器，负责加载和管理配置文件"""
    
    def __init__(self, config_path: str = "xianyu_config.json"):
        """初始化配置管理器"""
        self.config_path = config_path
        self.config = self._load_config()
        
    def _load_config(self) -> Dict[str, Any]:
        """加载配置文件"""
        try:
            if not os.path.exists(self.config_path):
                logger.warning(f"配置文件 {self.config_path} 不存在，将使用默认配置")
                return self._get_default_config()
                
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
                logger.info(f"已加载配置文件: {self.config_path}")
                return config
        except Exception as e:
            logger.error(f"加载配置文件失败: {e}")
            return self._get_default_config()
            
    def _get_default_config(self) -> Dict[str, Any]:
        """获取默认配置"""
        return {
            "version": "1.0.0",
            "bot_settings": {
                "token_refresh_interval": 1800,
                "token_retry_interval": 300,
                "heartbeat_interval": 30
            },
            "intent_rules": {
                "price": {
                    "keywords": ["便宜", "价", "砍价", "少点", "优惠", "打折", "降价", "多少钱", "贵", "便宜点"],
                    "patterns": ["\\d+元", "\\d+块", "能少\\d+", "\\d+[块元]钱", "[0-9]+", "打[0-9]+折"]
                },
                "product_type": {
                    "keywords": ["卖的是什么", "卖什么", "什么商品", "什么产品", "是什么", "卖的啥", "商品是什么", "什么东西", 
                                "什么类型", "什么款式", "什么型号", "卖的什么", "什么物品", "卖什么的"]
                }
            },
            "bargain_strategy": {
                "0": {
                    "discount_rate": 0.95,
                    "message_template": "价格是{original_price}元，可以优惠到{discount_price}元。"
                },
                "1": {
                    "discount_rate": 0.97,
                    "message_template": "最低{discount_price}元，已经很优惠了。"
                },
                "2+": {
                    "discount_rate": 1.0,
                    "message_template": "价格已经是最低{original_price}元，不能再优惠了。"
                }
            },
            "product_info": {
                "wrong_product_types": ["连衣裙", "裙子", "衣服", "鞋子", "包包", "手表", "首饰"],
                "product_type_message_template": "我们销售的是{title}，价格{price}元。"
            },
            "system_prompts": {
                "item_info_template": "你是闲鱼客服机器人，正在回答关于以下商品的问题：\n商品标题：{title}\n商品价格：{price}元\n商品分类：{category}\n商品描述：{desc}\n\n请始终基于此商品信息回答，不要编造或混淆商品类型。\n议价次数: {bargain_count}"
            }
        }
        
    def save_config(self) -> bool:
        """保存配置到文件"""
        try:
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, ensure_ascii=False, indent=4)
            logger.info(f"配置已保存到: {self.config_path}")
            return True
        except Exception as e:
            logger.error(f"保存配置失败: {e}")
            return False
            
    def get_bot_settings(self) -> Dict[str, Any]:
        """获取机器人设置"""
        return self.config.get("bot_settings", {})
        
    def get_intent_rules(self, intent_type: str) -> Dict[str, Any]:
        """获取意图规则"""
        intent_rules = self.config.get("intent_rules", {})
        return intent_rules.get(intent_type, {})
        
    def get_bargain_strategy(self, bargain_count: int) -> Dict[str, Any]:
        """获取议价策略"""
        bargain_strategy = self.config.get("bargain_strategy", {})
        
        # 如果议价次数大于等于2，使用2+的策略
        if bargain_count >= 2:
            return bargain_strategy.get("2+", {})
            
        # 否则使用对应次数的策略
        return bargain_strategy.get(str(bargain_count), {})
        
    def get_wrong_product_types(self) -> List[str]:
        """获取错误的商品类型列表"""
        product_info = self.config.get("product_info", {})
        return product_info.get("wrong_product_types", [])
        
    def get_product_type_message_template(self) -> str:
        """获取商品类型消息模板"""
        product_info = self.config.get("product_info", {})
        return product_info.get("product_type_message_template", "我们销售的是{title}，价格{price}元。")
        
    def get_item_info_template(self) -> str:
        """获取商品信息模板"""
        system_prompts = self.config.get("system_prompts", {})
        return system_prompts.get("item_info_template", "")
        
    def format_bargain_message(self, bargain_count: int, original_price: int) -> str:
        """格式化议价消息"""
        strategy = self.get_bargain_strategy(bargain_count)
        discount_rate = strategy.get("discount_rate", 1.0)
        message_template = strategy.get("message_template", "价格是{original_price}元。")
        
        # 计算折扣价格
        discount_price = int(original_price * discount_rate)
        
        # 格式化消息
        return message_template.format(
            original_price=original_price,
            discount_price=discount_price
        )
        
    def format_product_type_message(self, title: str, price: int) -> str:
        """格式化商品类型消息"""
        template = self.get_product_type_message_template()
        return template.format(title=title, price=price)
        
    def format_item_info_prompt(self, title: str, price: int, category: str, desc: str, bargain_count: int) -> str:
        """格式化商品信息提示"""
        template = self.get_item_info_template()
        return template.format(
            title=title,
            price=price,
            category=category,
            desc=desc,
            bargain_count=bargain_count
        )
        
    def is_price_intent(self, user_msg: str) -> bool:
        """检测是否为价格意图"""
        import re
        
        # 获取价格意图规则
        price_rules = self.get_intent_rules("price")
        keywords = price_rules.get("keywords", [])
        patterns = price_rules.get("patterns", [])
        
        # 清理文本，去除标点符号
        text_clean = re.sub(r'[^\w\u4e00-\u9fa5]', '', user_msg)
        
        # 检查关键词
        if any(kw in text_clean for kw in keywords):
            return True
            
        # 检查正则模式
        for pattern in patterns:
            if re.search(pattern, user_msg):
                return True
                
        return False
        
    def is_asking_product_type(self, user_msg: str) -> bool:
        """检测是否在询问商品类型"""
        product_type_rules = self.get_intent_rules("product_type")
        keywords = product_type_rules.get("keywords", [])
        
        for kw in keywords:
            if kw in user_msg:
                return True
        return False
        
    def contains_wrong_product_info(self, text: str, item_title: str, item_category: str) -> bool:
        """检测回复中是否包含错误的商品类型信息"""
        if not item_title or not item_category:
            return False
            
        # 获取错误的商品类型列表
        wrong_products = self.get_wrong_product_types()
        
        # 检查是否包含错误的商品类型
        for wrong in wrong_products:
            # 如果错误商品类型出现在回复中，且不是当前商品的类别或标题关键词
            if wrong in text and wrong not in item_title.lower() and wrong not in item_category.lower():
                return True
                
        return False 