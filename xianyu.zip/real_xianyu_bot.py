"""
闲鱼客服机器人测试脚本 - 使用真实API获取商品信息
"""
import asyncio
import json
import os
import time
import base64
from typing import Dict, Any, List, Optional
from loguru import logger

from XianyuAgent import XianyuReplyBot
from XianyuApis import XianyuApis
from utils.xianyu_utils import generate_mid, generate_uuid
from config_manager import ConfigManager

# 会话上下文管理
class SessionManager:
    def __init__(self):
        self.sessions = {}  # 会话ID -> 上下文
        self.bargain_counts = {}  # 会话ID -> 议价次数
        self.item_infos = {}  # 会话ID -> 商品信息
        
    def get_context(self, session_id: str) -> List[Dict[str, str]]:
        """获取会话上下文"""
        if session_id not in self.sessions:
            self.sessions[session_id] = []
        return self.sessions[session_id]
    
    def add_message(self, session_id: str, role: str, content: str):
        """添加消息到会话上下文"""
        if session_id not in self.sessions:
            self.sessions[session_id] = []
        self.sessions[session_id].append({"role": role, "content": content})
    
    def reset_session(self, session_id: str):
        """重置会话"""
        self.sessions[session_id] = []
        self.bargain_counts[session_id] = 0
        
    def increment_bargain_count(self, session_id: str):
        """增加议价次数"""
        if session_id not in self.bargain_counts:
            self.bargain_counts[session_id] = 0
        self.bargain_counts[session_id] += 1
        
    def get_bargain_count(self, session_id: str) -> int:
        """获取议价次数"""
        return self.bargain_counts.get(session_id, 0)
    
    def update_system_message(self, session_id: str, bargain_count: int):
        """更新系统消息中的议价次数"""
        # 查找并更新系统消息
        for i, msg in enumerate(self.sessions.get(session_id, [])):
            if msg.get('role') == 'system':
                # 如果已有系统消息，更新议价次数
                system_content = msg.get('content', '')
                if '议价次数' in system_content:
                    # 替换议价次数
                    new_content = re.sub(r'议价次数[:：]\s*\d+', f'议价次数: {bargain_count}', system_content)
                else:
                    # 添加议价次数
                    new_content = f"{system_content}\n议价次数: {bargain_count}"
                self.sessions[session_id][i]['content'] = new_content
                return
        
        # 如果没有找到系统消息，添加一个
        system_msg = {"role": "system", "content": f"议价次数: {bargain_count}"}
        # 确保系统消息在最前面
        self.sessions[session_id].insert(0, system_msg)
        
    def set_item_info(self, session_id: str, item_info: Dict[str, Any]):
        """设置会话的商品信息"""
        self.item_infos[session_id] = item_info
        
    def get_item_info(self, session_id: str) -> Dict[str, Any]:
        """获取会话的商品信息"""
        return self.item_infos.get(session_id, {})
        
    def add_item_reminder(self, session_id: str):
        """添加商品信息提醒"""
        item_info = self.get_item_info(session_id)
        if not item_info:
            return
            
        # 构建商品提醒消息
        title = item_info.get("title", "")
        price = item_info.get("price", 0)
        category = item_info.get("category", "")
        
        reminder = {
            "role": "system",
            "content": f"重要提醒：当前商品是「{title}」，价格{price}元，分类是{category}。请始终基于此商品信息回答，不要编造或混淆商品类型。"
        }
        
        # 添加到会话上下文
        self.sessions[session_id].append(reminder)

# 真实闲鱼客服机器人
class RealXianyuBot:
    def __init__(self, config_path: str = "xianyu_config.json"):
        self.bot = XianyuReplyBot()
        self.api = XianyuApis()
        self.session_manager = SessionManager()
        self.current_session_id = "default"
        self.current_item_id = None
        self.item_description = None
        self.item_title = None
        self.item_price = None
        self.item_category = None
        
        # 加载配置
        self.config_manager = ConfigManager(config_path)
        
        # 从配置获取保活相关设置
        bot_settings = self.config_manager.get_bot_settings()
        self.device_id = self.api.cookies.get('cna', '')
        self.current_token = None
        self.last_token_refresh_time = 0
        self.token_refresh_interval = bot_settings.get("token_refresh_interval", 1800)
        self.token_retry_interval = bot_settings.get("token_retry_interval", 300)
        self.heartbeat_interval = bot_settings.get("heartbeat_interval", 30)
        self.keep_alive_tasks = []
        
        # 检查是否使用百炼应用API
        self.is_dashscope_app = self.bot.config.get("provider_type", "") == "dashscope_app"
        if self.is_dashscope_app:
            logger.info("当前使用百炼应用API模式")
    
    async def start(self):
        """启动真实客服机器人"""
        print("=" * 60)
        print("闲鱼客服机器人 - 真实商品信息获取")
        print("=" * 60)
        print("可用命令:")
        print("  /item <商品ID>  - 输入商品ID获取真实商品信息")
        print("  /session <ID>  - 切换会话")
        print("  /reset         - 重置当前会话")
        print("  /bargain       - 查看议价次数")
        print("  /refresh       - 刷新token")
        print("  /remind        - 添加商品提醒")
        print("  /exit          - 退出程序")
        print("=" * 60)
        
        # 检查登录状态
        login_status = await self.api.hasLogin()
        if not login_status:
            print("⚠️ 闲鱼登录状态检查失败，请确保.env文件中的COOKIES_STR有效")
            print("继续使用可能会导致无法获取商品信息")
        else:
            print("✅ 闲鱼登录状态检查成功")
            
        # 启动保活任务
        self.start_keep_alive_tasks()
        
        try:
            # 进入对话循环
            while True:
                user_msg = input("\n你: ")
                
                # 处理命令
                if user_msg.startswith("/"):
                    result = await self.process_command(user_msg)
                    if not result:  # 如果返回False，表示退出程序
                        break
                    continue
                    
                # 处理普通消息
                await self.process_message(user_msg)
        finally:
            # 停止所有保活任务
            self.stop_keep_alive_tasks()
    
    def start_keep_alive_tasks(self):
        """启动保活任务"""
        # 创建token刷新任务
        token_refresh_task = asyncio.create_task(self.token_refresh_loop())
        self.keep_alive_tasks.append(token_refresh_task)
        logger.info("已启动token刷新任务")
    
    def stop_keep_alive_tasks(self):
        """停止所有保活任务"""
        for task in self.keep_alive_tasks:
            if not task.done():
                task.cancel()
        self.keep_alive_tasks = []
        logger.info("已停止所有保活任务")
    
    async def refresh_token(self):
        """刷新token"""
        try:
            # 获取token
            token_result = await self.api.get_token(self.device_id)
            if token_result and isinstance(token_result, dict) and "data" in token_result:
                self.current_token = token_result["data"].get("token")
                self.last_token_refresh_time = time.time()
                logger.info("Token刷新成功")
                return True
            else:
                logger.error(f"Token刷新失败: {token_result}")
                return False
        except Exception as e:
            logger.error(f"Token刷新出错: {e}")
            return False
    
    async def token_refresh_loop(self):
        """定时刷新token的循环"""
        while True:
            try:
                # 检查token是否需要刷新
                current_time = time.time()
                if not self.current_token or (current_time - self.last_token_refresh_time) >= self.token_refresh_interval:
                    logger.info("开始刷新token...")
                    refresh_success = await self.refresh_token()
                    
                    if refresh_success:
                        logger.info(f"Token刷新成功，下次刷新将在{self.token_refresh_interval//60}分钟后进行")
                    else:
                        logger.error(f"Token刷新失败，将在{self.token_retry_interval//60}分钟后重试")
                        await asyncio.sleep(self.token_retry_interval)
                        continue
                
                # 每分钟检查一次
                await asyncio.sleep(60)
                
            except Exception as e:
                logger.error(f"Token刷新循环出错: {e}")
                await asyncio.sleep(60)
    
    async def process_command(self, command: str) -> bool:
        """处理命令"""
        cmd_parts = command.strip().split()
        cmd = cmd_parts[0].lower()
        
        if cmd == "/exit":
            print("已退出程序")
            return False
            
        elif cmd == "/item" and len(cmd_parts) > 1:
            await self.get_item_info(cmd_parts[1])
            
        elif cmd == "/session" and len(cmd_parts) > 1:
            self.current_session_id = cmd_parts[1]
            print(f"已切换到会话: {self.current_session_id}")
            
        elif cmd == "/reset":
            self.session_manager.reset_session(self.current_session_id)
            # 安全地尝试重置会话（百炼应用专用）
            if self.is_dashscope_app:
                try:
                    # 使用getattr动态获取方法
                    reset_method = getattr(self.bot.provider, "reset_session", None)
                    if reset_method and callable(reset_method):
                        reset_method()
                        logger.debug("已重置百炼应用会话")
                except Exception as e:
                    logger.error(f"重置会话出错: {e}")
            print(f"已重置会话: {self.current_session_id}")
            
        elif cmd == "/bargain":
            count = self.session_manager.get_bargain_count(self.current_session_id)
            print(f"当前会话议价次数: {count}")
            
        elif cmd == "/refresh":
            print("正在手动刷新token...")
            success = await self.refresh_token()
            if success:
                print("✅ Token刷新成功")
            else:
                print("❌ Token刷新失败")
                
        elif cmd == "/remind":
            # 添加商品提醒
            self.session_manager.add_item_reminder(self.current_session_id)
            print("已添加商品提醒，防止机器人混淆商品信息")
            
        else:
            print("未知命令或参数不足")
            
        return True
    
    async def process_message(self, user_msg: str):
        """处理用户消息"""
        if not self.item_description:
            print("请先使用 /item <商品ID> 获取商品信息")
            return
            
        # 获取当前会话上下文
        context = self.session_manager.get_context(self.current_session_id)
        
        # 每隔5条消息添加一次商品提醒
        if len(context) > 0 and len(context) % 5 == 0:
            self.session_manager.add_item_reminder(self.current_session_id)
        
        # 检查是否为价格意图
        is_price_intent = self.config_manager.is_price_intent(user_msg)
        
        # 检查是否询问商品类型
        is_asking_product_type = self.config_manager.is_asking_product_type(user_msg)
        
        # 获取当前议价次数
        bargain_count = self.session_manager.get_bargain_count(self.current_session_id)
        
        # 特殊处理某些问题
        direct_reply = None
        
        # 添加用户消息到上下文
        if self.is_dashscope_app and self.item_title and self.item_price:
            # 在用户消息中添加商品信息提示
            enhanced_msg = f"[商品信息]标题:{self.item_title},价格:{self.item_price}元,商品类型:{self.item_category}\n\n{user_msg}"
            self.session_manager.add_message(self.current_session_id, "user", enhanced_msg)
        else:
            self.session_manager.add_message(self.current_session_id, "user", user_msg)
        
        # 如果有直接回复，使用它
        if direct_reply:
            reply = direct_reply
        else:
            # 生成回复
            reply = self.bot.generate_reply(user_msg, self.item_description, context)
            
            # 过滤引用标记
            reply = self.filter_reference_tags(reply)
            
            # 修正价格信息
            if "价格" in user_msg and self.item_price:
                if str(self.item_price) not in reply:
                    reply = f"价格是{self.item_price}元。"
            
        print(f"机器人: {reply}")
        
        # 添加回复到上下文
        self.session_manager.add_message(self.current_session_id, "assistant", reply)
        
        # 如果是价格意图，增加议价次数
        if is_price_intent:
            bargain_count = self.session_manager.get_bargain_count(self.current_session_id) + 1
            self.session_manager.increment_bargain_count(self.current_session_id)
            # 更新系统消息中的议价次数
            self.session_manager.update_system_message(self.current_session_id, bargain_count)
            logger.debug(f"议价次数增加到: {bargain_count}")
    
    def filter_reference_tags(self, text: str) -> str:
        """过滤引用标记"""
        import re
        # 过滤<ref>[数字]</ref>格式的引用标记
        filtered_text = re.sub(r'<ref>\s*\[\w+\]\s*</ref>', '', text)
        return filtered_text.strip()
    
    async def get_item_info(self, item_id: str):
        """获取真实商品信息"""
        try:
            print(f"正在获取商品信息: {item_id}...")
            
            # 获取商品信息
            api_result = await self.api.get_item_info(item_id)
            
            if isinstance(api_result, dict) and "data" in api_result and isinstance(api_result["data"], dict) and "itemDO" in api_result["data"]:
                item_info = api_result["data"]["itemDO"]
                self.current_item_id = item_id
                
                # 提取商品信息
                title = item_info.get("title", "无标题") if isinstance(item_info, dict) else "无标题"
                desc = item_info.get("desc", "无描述") if isinstance(item_info, dict) else "无描述"
                price = item_info.get("soldPrice", 0) if isinstance(item_info, dict) else 0
                category = item_info.get("category", "未知分类") if isinstance(item_info, dict) else "未知分类"
                location = item_info.get("location", "未知地区") if isinstance(item_info, dict) else "未知地区"
                
                # 保存商品信息
                self.item_title = title
                self.item_price = price
                self.item_category = category
                
                # 构建商品描述
                self.item_description = f"{desc};当前商品售卖价格为:{price}"
                
                # 保存商品信息到会话管理器
                self.session_manager.set_item_info(self.current_session_id, {
                    "title": title,
                    "price": price,
                    "category": category,
                    "desc": desc,
                    "location": location
                })
                
                print(f"\n=== 商品信息 ===")
                print(f"标题: {title}")
                print(f"价格: {price}元")
                print(f"分类: {category}")
                print(f"地区: {location}")
                print(f"描述: {desc}")
                print(f"=== 商品信息结束 ===\n")
                
                # 重置会话
                self.session_manager.reset_session(self.current_session_id)
                
                # 添加商品信息系统提示
                system_prompt = self.config_manager.format_item_info_prompt(
                    title=title,
                    price=price,
                    category=category,
                    desc=desc,
                    bargain_count=0
                )
                
                self.session_manager.add_message(self.current_session_id, "system", system_prompt)
                
                # 安全地尝试重置会话（百炼应用专用）
                if self.is_dashscope_app:
                    try:
                        # 使用getattr动态获取方法
                        reset_method = getattr(self.bot.provider, "reset_session", None)
                        if reset_method and callable(reset_method):
                            reset_method()
                            logger.debug("已重置百炼应用会话")
                            
                            # 为百炼应用添加初始化消息，确保它知道商品信息
                            init_msg = f"我是客户，我想咨询这个商品：{title}，价格{price}元，是{category}类商品。"
                            init_reply = self.bot.generate_reply(init_msg, self.item_description, [])
                            init_reply = self.filter_reference_tags(init_reply)
                            logger.debug(f"百炼应用初始化完成: {init_reply}")
                    except Exception as e:
                        logger.error(f"重置会话出错: {e}")
                
                print("现在可以开始与机器人对话了！")
                    
            else:
                error_msg = api_result.get("error", "未知错误")
                print(f"获取商品信息失败: {error_msg}")
                if "令牌过期" in str(api_result) or "TOKEN_EXPIRED" in str(api_result):
                    print("⚠️ 闲鱼登录令牌已过期，尝试刷新token...")
                    refresh_success = await self.refresh_token()
                    if refresh_success:
                        print("✅ Token刷新成功，请重新获取商品信息")
                    else:
                        print("❌ Token刷新失败，请更新.env文件中的COOKIES_STR")
                
        except Exception as e:
            print(f"获取商品信息出错: {e}")

async def main():
    bot = RealXianyuBot()
    await bot.start()

if __name__ == "__main__":
    # 设置日志级别，过滤掉不必要的日志
    logger.remove()
    logger.add(lambda msg: print(msg, end=""), level="WARNING")
    
    # 导入正则表达式模块
    import re
    
    asyncio.run(main()) 