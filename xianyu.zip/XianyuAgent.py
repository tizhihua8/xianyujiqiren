import re
from typing import List, Dict, Any, Optional, Union, cast, Iterable
import os
from http import HTTPStatus
import json
import requests
from abc import ABC, abstractmethod
from loguru import logger
# 导入dotenv库以支持.env文件
try:
    from dotenv import load_dotenv
    HAS_DOTENV = True
    # 尝试加载.env文件
    load_dotenv()
    logger.info("已加载.env环境变量")
except ImportError:
    HAS_DOTENV = False
    logger.warning("未找到python-dotenv库，无法从.env文件加载配置")

# 导入配置管理器
try:
    from config_manager import ConfigManager
    HAS_CONFIG_MANAGER = True
    logger.info("已加载配置管理器")
except ImportError:
    HAS_CONFIG_MANAGER = False
    logger.warning("未找到config_manager模块，将使用默认配置")

# 导入CKD模块以便联动
try:
    import ckd  # 联动CKD.py
except ImportError:
    logger.warning("未找到CKD模块，快递查询功能将受限")

# 尝试导入OpenAI
HAS_OPENAI = False
try:
    from openai import OpenAI
    from openai.types.chat import ChatCompletionMessageParam
    HAS_OPENAI = True
except ImportError:
    logger.warning("未找到openai模块，OpenAI模式将不可用")

# 尝试导入百炼模型
HAS_DASHSCOPE_MODEL = False
try:
    import dashscope
    from dashscope.aigc.generation import Generation
    HAS_DASHSCOPE_MODEL = True
except ImportError:
    logger.warning("未找到dashscope模块，百炼模型功能将受限")

# 尝试导入百炼应用
HAS_DASHSCOPE_APP = False
try:
    from dashscope import Application
    HAS_DASHSCOPE_APP = True
except ImportError:
    logger.warning("未找到dashscope.Application模块，百炼应用功能将受限")

# 导入模型提供商工厂
try:
    from providers import create_provider, LLMProvider
    HAS_PROVIDERS = True
except ImportError:
    HAS_PROVIDERS = False
    logger.warning("未找到providers包，请确保该包已正确安装")
    from providers_fallback import LLMProvider

import ckd
import asyncio


class LLMProvider(ABC):
    """LLM提供商抽象基类"""
    
    @abstractmethod
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.4, max_tokens: int = 500, **kwargs) -> str:
        """调用模型生成回复"""
        pass
    
    @property
    @abstractmethod
    def provider_name(self) -> str:
        """获取提供商名称"""
        pass


class OpenAIProvider(LLMProvider):
    """OpenAI API提供商"""
    
    def __init__(self, api_key: str, base_url: str, model_name: str):
        if not HAS_OPENAI:
            raise ImportError("请先安装openai库: pip install openai")
            
        self.client = OpenAI(
            api_key=api_key,
            base_url=base_url,
        )
        self.model_name = model_name
        self._session_id = None
    
    @property
    def provider_name(self) -> str:
        return "openai"
    
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.4, max_tokens: int = 500, **kwargs) -> str:
        """使用OpenAI接口调用模型"""
        extra_body = kwargs.get("extra_body", {})
        
        # 转换为OpenAI支持的消息格式
        openai_messages = []
        for msg in messages:
            if 'role' in msg and 'content' in msg:
                # 创建符合OpenAI格式的消息
                openai_messages.append({
                    "role": msg["role"],
                    "content": msg["content"]
                })
        
        try:
            # 调用API
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=openai_messages,
                temperature=temperature,
                max_tokens=max_tokens,
                top_p=0.8,
                **extra_body
            )
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"OpenAI API调用失败: {e}")
            return f"模型调用出错，请稍后再试。错误: {str(e)[:100]}"


class DashscopeModelProvider(LLMProvider):
    """阿里云百炼模型API提供商"""
    
    def __init__(self, api_key: str, model_name: str):
        if not HAS_DASHSCOPE_MODEL:
            raise ImportError("请先安装dashscope库: pip install dashscope")
        
        dashscope.api_key = api_key
        self.model_name = model_name
        self._session_id = None
    
    @property
    def provider_name(self) -> str:
        return "dashscope_model"
    
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.4, max_tokens: int = 500, **kwargs) -> str:
        """使用百炼模型接口调用模型"""
        try:
            # 百炼API参数映射
            response = Generation.call(
                model=self.model_name,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                top_p=0.8,
                result_format='message',  # 返回格式
            )
            
            if response.status_code == HTTPStatus.OK:
                return response.output.choices[0]['message']['content']
            else:
                logger.error(f"百炼API调用失败: {response.code} - {response.message}")
                return f"模型调用出错，请稍后再试。错误码: {response.code}"
        except Exception as e:
            logger.error(f"百炼模型调用失败: {e}")
            return f"模型调用出错，请稍后再试。错误: {str(e)[:100]}"


class DashscopeAppProvider(LLMProvider):
    """阿里云百炼应用API提供商"""
    
    def __init__(self, api_key: str, app_id: str):
        if not HAS_DASHSCOPE_APP:
            raise ImportError("请先安装dashscope库: pip install dashscope")
        
        self.api_key = api_key
        self.app_id = app_id
        self._session_id = None  # 保存会话ID
    
    @property
    def provider_name(self) -> str:
        return "dashscope_app"
    
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.4, max_tokens: int = 500, **kwargs) -> str:
        """使用百炼应用接口调用模型"""
        try:
            # 获取最新的用户消息
            user_message = messages[-1]["content"] if messages else ""
            
            # 构建调用参数
            call_params = {
                "api_key": self.api_key,
                "app_id": self.app_id,
                "prompt": user_message
            }
            
            # 如果有会话ID，添加到请求中
            if self._session_id:
                call_params["session_id"] = self._session_id
                
            # 调用百炼应用
            response = Application.call(**call_params)
            
            if response.status_code == HTTPStatus.OK:
                # 保存会话ID以便下次使用
                if hasattr(response.output, "session_id"):
                    self._session_id = response.output.session_id
                
                # 返回模型回复
                return response.output.text
            else:
                logger.error(f"百炼应用调用失败: {response.status_code} - {response.message}")
                return f"应用调用出错，请稍后再试。错误码: {response.status_code}"
        except Exception as e:
            logger.error(f"百炼应用调用失败: {e}")
            return f"应用调用出错，请稍后再试。错误: {str(e)[:100]}"


class CustomHTTPProvider(LLMProvider):
    """自定义HTTP接口提供商"""
    
    def __init__(self, api_url: str, headers: Optional[Dict[str, str]] = None, provider_type: str = "custom"):
        self.api_url = api_url
        self.headers = headers or {"Content-Type": "application/json"}
        self._provider_type = provider_type  # 自定义提供商类型名称
    
    @property
    def provider_name(self) -> str:
        return self._provider_type
    
    def chat_completion(self, messages: List[Dict[str, str]], temperature: float = 0.4, max_tokens: int = 500, **kwargs) -> str:
        """使用自定义HTTP接口调用模型"""
        payload = {
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "top_p": 0.8,
        }
        
        # 合并其他参数
        extra_params = kwargs.get("extra_params", {})
        if extra_params and isinstance(extra_params, dict):
            payload.update(extra_params)
        
        try:
            response = requests.post(self.api_url, headers=self.headers, json=payload)
            response.raise_for_status()
            
            # 解析返回结果 (根据实际接口调整)
            result = response.json()
            
            # 灵活处理不同格式的返回结果
            if "choices" in result and len(result["choices"]) > 0:
                if "message" in result["choices"][0] and "content" in result["choices"][0]["message"]:
                    return result["choices"][0]["message"]["content"]
                elif "text" in result["choices"][0]:
                    return result["choices"][0]["text"]
            elif "output" in result and "text" in result["output"]:
                return result["output"]["text"]
            else:
                logger.error(f"未知的HTTP接口返回格式: {result}")
                return "接口返回格式不支持，请联系管理员"
        except Exception as e:
            logger.error(f"HTTP接口调用失败: {e}")
            return f"模型调用出错，请稍后再试。错误: {str(e)[:100]}"


class XianyuReplyBot:
    def __init__(self, config_path: str = "config.json", xianyu_config_path: str = "xianyu_config.json"):
        # 加载配置文件
        self.config = self._load_config(config_path)
        self.toggle_keyword = self.config.get('toggle_keyword', '切换人工')
        self.human_takeover = False  # 人工接管模式
        self.last_intent = None  # 记录上一次的意图
        
        # 初始化配置管理器
        if HAS_CONFIG_MANAGER:
            self.config_manager = ConfigManager(xianyu_config_path)
            logger.info(f"已加载闲鱼配置: {xianyu_config_path}")
        else:
            self.config_manager = None
            logger.warning("未找到配置管理器，将使用默认配置")
        
        # 初始化LLM提供商
        self.provider = self._init_provider()
        
        # 初始化系统提示词
        self._init_system_prompts()
        
        # 确保system_prompts已经初始化
        if not hasattr(self, 'system_prompts'):
            logger.warning("系统提示词未正确初始化，使用默认值")
            self.system_prompts = {
                'classify': self._load_prompt("prompts/classify_prompt.txt"),
                'price': self._load_prompt("prompts/price_prompt.txt"),
                'tech': self._load_prompt("prompts/tech_prompt.txt"),
                'express': self._load_prompt("prompts/express_prompt.txt"),
                'default': self._load_prompt("prompts/default_prompt.txt"),
            }
        
        # 初始化各种Agent
        self._init_agents()
        self.router = IntentRouter(self.agents['classify'])
        self._prompts_mtime = self._get_prompts_mtime()

    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """加载配置文件"""
        # 优先从环境变量获取配置
        provider_type = os.getenv("PROVIDER_TYPE", "").lower()
        cookies_str = os.getenv("COOKIES_STR", "")
        toggle_keyword = os.getenv("TOGGLE_KEYWORDS", ".")
        
        # 应用ID (百炼应用专用)
        app_id = os.getenv("APP_ID", "")
        
        # 基础环境变量配置
        env_config = {
            "provider_type": provider_type if provider_type else "dashscope_model",  # 默认使用通义千问模型
            "api_key": os.getenv("API_KEY", ""),
            "base_url": os.getenv("MODEL_BASE_URL", ""),
            "model_name": os.getenv("MODEL_NAME", ""),
            "api_url": os.getenv("API_URL", ""),
            "app_id": app_id,  # 百炼应用ID
            "cookies_str": cookies_str,
            "toggle_keyword": toggle_keyword,
            "headers": {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {os.getenv('API_KEY', '')}"
            }
        }
        
        # 如果环境变量有提供商类型配置，直接使用环境变量配置
        if provider_type:
            logger.info(f"使用环境变量配置，提供商类型: {provider_type}")
            return env_config
        
        # 否则尝试从配置文件加载
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            logger.info(f"成功加载配置文件: {config_path}")
            
            # 合并环境变量中的cookies和toggle_keyword到配置
            if cookies_str:
                config["cookies_str"] = cookies_str
            if toggle_keyword:
                config["toggle_keyword"] = toggle_keyword
            if app_id:
                config["app_id"] = app_id
                
            return config
        except FileNotFoundError:
            logger.warning(f"配置文件 {config_path} 不存在，使用环境变量配置")
            return env_config
        except json.JSONDecodeError:
            logger.error(f"配置文件格式错误: {config_path}")
            raise

    def _init_provider(self) -> LLMProvider:
        """初始化LLM提供商"""
        if not HAS_PROVIDERS:
            from providers_fallback import FallbackProvider
            logger.error("providers包不可用，使用内置的回退提供商")
            return FallbackProvider()
        
        # 检查是否有API密钥
        api_key = self.config.get("api_key") or os.getenv("API_KEY", "")
        if not api_key:
            logger.warning("未配置API密钥，使用回退提供商")
            from providers_fallback import FallbackProvider
            return FallbackProvider()
            
        # 使用工厂函数创建提供商
        return create_provider(self.config)

    def _init_agents(self):
        """初始化各种Agent"""
        try:
            # 分类Agent
            self.agents = {}
            classify_agent = ClassifyAgent(
                provider=self.provider,
                system_prompt=self.system_prompts['classify'],
                safety_filter=self._safe_filter
            )
            
            # 意图路由
            self.router = IntentRouter(classify_agent)
            
            # 如果有配置管理器，更新路由规则
            if hasattr(self, 'config_manager') and self.config_manager:
                try:
                    # 更新价格意图规则
                    price_rules = self.config_manager.get_intent_rules("price")
                    if price_rules:
                        self.router.rules['price']['keywords'] = price_rules.get('keywords', self.router.rules['price']['keywords'])
                        self.router.rules['price']['patterns'] = price_rules.get('patterns', self.router.rules['price']['patterns'])
                    
                    # 更新产品类型意图规则
                    product_type_rules = self.config_manager.get_intent_rules("product_type")
                    if product_type_rules:
                        if 'product_type' not in self.router.rules:
                            self.router.rules['product_type'] = {'keywords': [], 'patterns': []}
                        self.router.rules['product_type']['keywords'] = product_type_rules.get('keywords', [])
                except Exception as e:
                    logger.error(f"更新路由规则失败: {e}")
            
            # 价格Agent
            self.agents['price'] = PriceAgent(
                provider=self.provider,
                system_prompt=self.system_prompts['price'],
                safety_filter=self._safe_filter
            )
            
            # 技术Agent
            self.agents['tech'] = TechAgent(
                provider=self.provider,
                system_prompt=self.system_prompts['tech'],
                safety_filter=self._safe_filter
            )
            
            # 快递Agent
            self.agents['express'] = ExpressAgent(
                provider=self.provider,
                system_prompt=self.system_prompts['express'],
                safety_filter=self._safe_filter
            )
            
            # 默认Agent
            self.agents['default'] = DefaultAgent(
                provider=self.provider,
                system_prompt=self.system_prompts['default'],
                safety_filter=self._safe_filter
            )
            
            # 分类Agent
            self.agents['classify'] = classify_agent
        except Exception as e:
            logger.error(f"初始化Agent失败: {e}")
            # 回退到简单初始化
            self.agents = {
                'classify': ClassifyAgent(self.provider, self.system_prompts['classify'], self._safe_filter),
                'price': PriceAgent(self.provider, self.system_prompts['price'], self._safe_filter),
                'tech': TechAgent(self.provider, self.system_prompts['tech'], self._safe_filter),
                'express': ExpressAgent(self.provider, self.system_prompts['express'], self._safe_filter),
                'default': DefaultAgent(self.provider, self.system_prompts['default'], self._safe_filter),
            }
            self.router = IntentRouter(self.agents['classify'])

    def _init_system_prompts(self):
        """初始化系统提示词"""
        try:
            # 基础提示词
            base_prompts = {
                'classify': self._load_prompt("prompts/classify_prompt.txt"),
                'price': self._load_prompt("prompts/price_prompt.txt"),
                'tech': self._load_prompt("prompts/tech_prompt.txt"),
                'express': self._load_prompt("prompts/express_prompt.txt"),
                'default': self._load_prompt("prompts/default_prompt.txt"),
            }
            
            # 添加模型信息到提示词
            model_info = ""
            if hasattr(self, 'provider'):
                model_info = f"\n\n你是基于{self.provider.provider_name}的AI助手"
                if hasattr(self.provider, 'model') and self.provider.provider_name == "chutes":
                    model_info += f"，使用的模型是{self.provider.model}"
                elif hasattr(self.provider, 'model_name'):
                    model_info += f"，使用的模型是{self.provider.model_name}"
                    
            # 将模型信息添加到每个提示词中
            self.system_prompts = {}
            for key, prompt in base_prompts.items():
                self.system_prompts[key] = prompt + model_info
                
            logger.info("系统提示词加载完成")
        except Exception as e:
            logger.error(f"加载系统提示词失败: {e}")
            # 设置默认提示词
            self.system_prompts = {
                'classify': "你是一个分类助手，请判断用户的问题属于哪个类别：价格、技术、快递、其他",
                'price': "你是一个价格顾问，请根据商品信息回答用户的价格相关问题",
                'tech': "你是一个技术顾问，请根据商品信息回答用户的技术相关问题",
                'express': "你是一个物流顾问，请根据商品信息回答用户的物流相关问题",
                'default': "你是一个客服助手，请根据商品信息回答用户的问题",
            }
            logger.warning("使用默认系统提示词")

    def _safe_filter(self, text: str) -> str:
        """过滤敏感内容"""
        # 过滤思考标记
        import re
        text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL)
        
        # 简单过滤，可以根据需要扩展
        text = text.replace("联系方式", "**")
        text = text.replace("微信", "**")
        text = text.replace("电话", "**")
        return text.strip()
        
    def _load_prompt(self, prompt_path: str) -> str:
        """从文件加载提示词
        
        Args:
            prompt_path: 提示词文件路径
            
        Returns:
            str: 提示词内容
        """
        try:
            with open(prompt_path, "r", encoding="utf-8") as f:
                prompt = f.read()
                logger.debug(f"已加载提示词 {prompt_path}，长度: {len(prompt)} 字符")
                return prompt
        except FileNotFoundError:
            logger.warning(f"未找到提示词文件: {prompt_path}，使用默认提示词")
            # 返回简单的默认提示词
            return f"你是闲鱼客服机器人，请根据商品信息回答用户问题。"
        except Exception as e:
            logger.error(f"加载提示词文件失败: {e}")
            return f"你是闲鱼客服机器人，请根据商品信息回答用户问题。"

    def format_history(self, context: List[Dict]) -> str:
        """格式化对话历史，返回完整的对话记录"""
        # 过滤掉系统消息，只保留用户和助手的对话
        user_assistant_msgs = [msg for msg in context if msg['role'] in ['user', 'assistant']]
        return "\n".join([f"{msg['role']}: {msg['content']}" for msg in user_assistant_msgs])

    def generate_reply(self, user_msg: str, item_desc: str, context: List[Dict]) -> str:
        """生成回复主流程"""
        # 检查是否需要切换人工/AI接管模式
        if user_msg.strip() == self.toggle_keyword:
            self.human_takeover = not self.human_takeover
            mode = "人工接管" if self.human_takeover else "AI接管"
            return f"[系统通知] 已切换为{mode}模式"
        
        # 格式化上下文
        formatted_context = self.format_history(context)
        
        # 检查是否使用百炼应用API（它有特殊处理）
        is_dashscope_app = self.config.get("provider_type", "") == "dashscope_app"
        
        if is_dashscope_app:
            # 百炼应用API特殊处理
            enhanced_msg = user_msg
            if item_desc:
                try:
                    item_info = self._extract_item_info(item_desc)
                    title = item_info.get("title", "")
                    price = item_info.get("price", 0)
                    category = item_info.get("category", "")
                    if not any(msg.get("role") == "assistant" for msg in context):
                        enhanced_msg = f"商品描述：{item_desc}\n\n用户问题：{user_msg}"
                    else:
                        if hasattr(self, 'config_manager') and self.config_manager and title and price:
                            enhanced_msg = f"[商品信息]标题:{title},价格:{price}元,商品类型:{category}\n\n{user_msg}"
                except Exception as e:
                    logger.error(f"处理商品信息失败: {e}")
            messages = [
                {"role": "user", "content": enhanced_msg}
            ]
            try:
                response = self.provider.chat_completion(messages)
                return response
            except Exception as e:
                logger.error(f"百炼应用调用失败: {e}")
                return f"抱歉，系统暂时无法回复，请稍后再试"
        # 1. 路由决策
        detected_intent = self.router.detect(user_msg, item_desc, formatted_context)
        # 2. 获取对应Agent
        internal_intents = {'classify'}
        if detected_intent in self.agents and detected_intent not in internal_intents:
            agent = self.agents[detected_intent]
            logger.info(f'意图识别完成: {detected_intent}')
            self.last_intent = detected_intent
        else:
            agent = self.agents['default']
            logger.info(f'意图识别完成: default')
            self.last_intent = 'default'
        # 3. 获取议价次数
        bargain_count = self._extract_bargain_count(context)
        logger.info(f'议价次数: {bargain_count}')
        # 4. 生成回复
        reply = agent.generate(
            user_msg=user_msg,
            item_desc=item_desc,
            context=formatted_context,
            bargain_count=bargain_count
        )
        return reply

    def _extract_item_info(self, item_desc: str) -> Dict[str, Any]:
        """从商品描述中提取商品信息"""
        if not item_desc:
            return {}
            
        result = {}
        
        # 提取标题
        title_match = re.search(r'标题[:：](.+?)(?:;|；|$)', item_desc)
        if title_match:
            result["title"] = title_match.group(1).strip()
        
        # 提取价格
        price_match = re.search(r'价格[:：](\d+)(?:;|；|$)|当前商品售卖价格为[:](\d+)(?:;|；|$)', item_desc)
        if price_match:
            price = price_match.group(1) or price_match.group(2)
            if price:
                result["price"] = int(price)
        
        # 提取分类
        category_match = re.search(r'分类[:：](.+?)(?:;|；|$)', item_desc)
        if category_match:
            result["category"] = category_match.group(1).strip()
        
        # 提取描述
        desc_match = re.search(r'描述[:：](.+?)(?:;|；|$)', item_desc)
        if desc_match:
            result["desc"] = desc_match.group(1).strip()
        else:
            # 如果没有明确的描述字段，使用整个item_desc
            result["desc"] = item_desc
        
        # 添加模型信息，让AI知道自己是什么模型
        if hasattr(self, 'provider') and hasattr(self.provider, 'provider_name'):
            result["model_type"] = self.provider.provider_name
            
            # 如果是Chutes提供商，添加具体模型名称
            if self.provider.provider_name == "chutes" and hasattr(self.provider, 'model'):
                result["model_name"] = self.provider.model
            # 如果是OpenAI提供商
            elif hasattr(self.provider, 'model_name'):
                result["model_name"] = self.provider.model_name
            
        return result
    
    def _filter_reference_tags(self, text: str) -> str:
        """过滤引用标记"""
        # 过滤<ref>[数字]</ref>格式的引用标记
        filtered_text = re.sub(r'<ref>\s*\[\w+\]\s*</ref>', '', text)
        return filtered_text.strip()
    
    def _extract_bargain_count(self, context: List[Dict]) -> int:
        """
        从上下文中提取议价次数信息
        
        Args:
            context: 对话历史
            
        Returns:
            int: 议价次数，如果没有找到则返回0
        """
        # 查找系统消息中的议价次数信息
        for msg in context:
            if msg['role'] == 'system' and '议价次数' in msg['content']:
                try:
                    # 提取议价次数
                    match = re.search(r'议价次数[:：]\s*(\d+)', msg['content'])
                    if match:
                        return int(match.group(1))
                except Exception:
                    pass
        return 0

    def reload_prompts(self):
        """重新加载所有提示词"""
        logger.info("正在重新加载提示词...")
        self._init_system_prompts()
        self._init_agents()
        logger.info("提示词重新加载完成")

    def _get_prompts_mtime(self):
        """获取prompts目录下所有提示词文件的最新修改时间"""
        prompts_dir = "prompts"
        latest_mtime = 0
        if os.path.exists(prompts_dir):
            for fname in os.listdir(prompts_dir):
                fpath = os.path.join(prompts_dir, fname)
                if os.path.isfile(fpath):
                    mtime = os.path.getmtime(fpath)
                    if mtime > latest_mtime:
                        latest_mtime = mtime
        return latest_mtime
    
    def _check_and_reload_prompts(self):
        """检测prompts目录下的文件是否有变动，如有则reload"""
        new_mtime = self._get_prompts_mtime()
        if new_mtime > self._prompts_mtime:
            logger.info("检测到提示词文件变动，自动重新加载提示词...")
            self.reload_prompts()
            self._prompts_mtime = new_mtime


class IntentRouter:
    """意图路由决策器"""

    def __init__(self, classify_agent):
        self.rules = {
            'tech': {  # 技术类优先判定
                'keywords': ['参数', '规格', '型号', '连接', '对比'],
                'patterns': [
                    r'和.+比'             
                ]
            },
            'price': {
                'keywords': ['便宜', '价', '砍价', '少点'],
                'patterns': [r'\d+元', r'能少\d+']
            },
            'express': {  # 新增快递类意图
                'keywords': ['发货', '快递', '物流', '邮费', '运费', '几天到', '什么时候到', '到货', '发出', '发出来', '什么快递', 
                             '多少钱', '费用', '包邮', '寄过来', '寄送', '运输', '配送', '送货', '邮寄'],
                'patterns': [r'多久.*送到', r'怎么.*邮寄', r'几天.*到', r'运费.*多少', r'快递.*多少钱', 
                             r'从.*到.*多少(?:钱|元)', r'(?:寄|邮).*(?:到|至).*(?:多少|几天|怎么)']
            }
        }
        self.classify_agent = classify_agent

    def detect(self, user_msg: str, item_desc, context) -> str:
        """三级路由策略（技术优先）"""
        text_clean = re.sub(r'[^\w\u4e00-\u9fa5]', '', user_msg)
        
        # 1. 技术类关键词优先检查
        if any(kw in text_clean for kw in self.rules['tech']['keywords']):
            # logger.debug(f"技术类关键词匹配: {[kw for kw in self.rules['tech']['keywords'] if kw in text_clean]}")
            return 'tech'
            
        # 2. 技术类正则优先检查
        for pattern in self.rules['tech']['patterns']:
            if re.search(pattern, text_clean):
                # logger.debug(f"技术类正则匹配: {pattern}")
                return 'tech'

        # 3. 价格类检查
        if any(kw in text_clean for kw in self.rules['price']['keywords']):
            # logger.debug(f"价格类关键词匹配: {[kw for kw in self.rules[intent]['keywords'] if kw in text_clean]}")
            return 'price'
            
        for pattern in self.rules['price']['patterns']:
            if re.search(pattern, text_clean):
                # logger.debug(f"价格类正则匹配: {pattern}")
                return 'price'
                
        # 4. 快递类检查
        if any(kw in text_clean for kw in self.rules['express']['keywords']):
            # logger.debug(f"快递类关键词匹配: {[kw for kw in self.rules['express']['keywords'] if kw in text_clean]}")
            return 'express'
            
        for pattern in self.rules['express']['patterns']:
            if re.search(pattern, text_clean):
                # logger.debug(f"快递类正则匹配: {pattern}")
                return 'express'
        
        # 5. 大模型兜底
        # logger.debug("使用大模型进行意图分类")
        return self.classify_agent.generate(
            user_msg=user_msg,
            item_desc=item_desc,
            context=context
        )


class BaseAgent:
    """基础Agent类"""

    def __init__(self, provider: LLMProvider, system_prompt: str, safety_filter):
        self.provider = provider
        self.system_prompt = system_prompt
        self.safety_filter = safety_filter

    def generate(self, user_msg: str, item_desc: str, context: str, bargain_count: int = 0) -> str:
        """生成回复"""
        messages = self._build_messages(user_msg, item_desc, context)
        return self._call_llm(messages)

    def _build_messages(self, user_msg: str, item_desc: str, context: str) -> List[Dict]:
        """构建消息列表"""
        return [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": f"【商品信息】\n{item_desc}\n\n【你与客户的对话历史】\n{context}\n\n【客户的问题】\n{user_msg}"}
        ]
    
    def _call_llm(self, messages: List[Dict], temperature: float = 0.7) -> str:
        """调用LLM生成回复"""
        try:
            # 增加温度参数，使回复更加自然
            response = self.provider.chat_completion(messages, temperature=temperature)
            # 应用安全过滤
            filtered = self.safety_filter(response)
            
            # 检查回复是否太短或太机械
            if len(filtered) < 10 or filtered.count('\n') > 3:
                # 如果回复太短或格式不佳，尝试再次生成，要求更详细友好的回复
                enhance_messages = messages.copy()
                enhance_messages.append({"role": "assistant", "content": filtered})
                enhance_messages.append({
                    "role": "user", 
                    "content": "请优化你的回复，使其更加友好、自然且有帮助。遵循提示词中的风格要求，但确保回复内容丰富、有价值。"
                })
                
                enhanced_response = self.provider.chat_completion(enhance_messages, temperature=temperature)
                return self.safety_filter(enhanced_response)
            
            return filtered
        except Exception as e:
            logger.error(f"调用LLM失败: {e}")
            return "抱歉，系统暂时无法回复，请稍后再试"


class PriceAgent(BaseAgent):
    """价格Agent，处理价格相关问题"""

    def generate(self, user_msg: str, item_desc: str, context: str, bargain_count: int=0) -> str:
        """生成价格相关回复"""
        # 提取商品价格信息
        price_match = re.search(r'价格[:：](\d+)(?:;|；|$)|当前商品售卖价格为[:](\d+)(?:;|；|$)', item_desc)
        price = 0
        if price_match:
            price_str = price_match.group(1) or price_match.group(2)
            if price_str:
                price = int(price_str)
        
        # 构建消息列表，添加价格和议价次数信息
        messages = self._build_messages(user_msg, item_desc, context)
        messages[0]["content"] += f"\n\n【价格信息】原价: {price}元，议价次数: {bargain_count}"
        
        # 调用LLM生成回复
        return self._call_llm(messages, temperature=self._calc_temperature(bargain_count))

    def _calc_temperature(self, bargain_count: int) -> float:
        """根据议价次数调整温度参数"""
        # 议价次数越多，回复越坚决（温度越低）
        return max(0.3, 0.7 - bargain_count * 0.1)


class TechAgent(BaseAgent):
    """技术Agent，处理技术相关问题"""
    
    def generate(self, user_msg: str, item_desc: str, context: str, bargain_count: int=0) -> str:
        """生成技术相关回复"""
        # 提取商品信息中可能的技术参数
        tech_info = self._extract_tech_info(item_desc)
        
        # 构建消息列表，添加技术参数信息
        messages = self._build_messages(user_msg, item_desc, context)
        if tech_info:
            messages[0]["content"] += f"\n\n【技术参数】{tech_info}"
        
        # 调用LLM生成回复
        return self._call_llm(messages, temperature=0.6)
        
    def _extract_tech_info(self, item_desc: str) -> str:
        """从商品描述中提取技术参数"""
        tech_info = []
        
        # 提取可能的技术参数
        # 手机类参数
        if "手机" in item_desc or "智能机" in item_desc or "iPhone" in item_desc.lower():
            ram_match = re.search(r'(\d+)[Gg][Bb]?\s*[+/]\s*(\d+)[Gg][Bb]', item_desc)
            if ram_match:
                tech_info.append(f"内存+存储: {ram_match.group(1)}GB+{ram_match.group(2)}GB")
            
            battery_match = re.search(r'电池[容量]?[为:]?\s*(\d+)\s*[mM][Aa][Hh]', item_desc)
            if battery_match:
                tech_info.append(f"电池容量: {battery_match.group(1)}mAh")
                
            health_match = re.search(r'[电池]?健康[度值]?[为:]?\s*(\d+)[%％]', item_desc)
            if health_match:
                tech_info.append(f"电池健康度: {health_match.group(1)}%")
        
        # 电脑类参数
        if "电脑" in item_desc or "笔记本" in item_desc or "台式机" in item_desc:
            cpu_match = re.search(r'[处理器]?[Cc][Pp][Uu][为:]?\s*([Ii]\d|[Rr]\d|[^,;，；]{2,20}?(?:处理器)?)', item_desc)
            if cpu_match:
                tech_info.append(f"处理器: {cpu_match.group(1)}")
                
            gpu_match = re.search(r'[显卡]?[Gg][Pp][Uu][为:]?\s*([^,;，；]{2,20}?(?:显卡)?)', item_desc)
            if gpu_match:
                tech_info.append(f"显卡: {gpu_match.group(1)}")
        
        return "，".join(tech_info)


class ExpressAgent(BaseAgent):
    """快递Agent，处理快递相关问题"""
    
    def __init__(self, provider: LLMProvider, system_prompt, safety_filter):
        super().__init__(provider, system_prompt, safety_filter)

    def generate(self, user_msg: str, item_desc: str, context: str, bargain_count: int=0) -> str:
        # 极简主流程：只交给AI，检测查价信号
        messages = self._build_messages(user_msg, item_desc, context)
        ai_reply = self._call_llm(messages, temperature=0.6)
        if "【需要查价】" in ai_reply:
            info = self._extract_express_info(user_msg, context)
            ckd_result = self._call_ckd(info)
            messages = self._build_messages(f"{user_msg}\n查价结果：{ckd_result}", item_desc, context)
            final_reply = self._call_llm(messages, temperature=0.6)
            return final_reply
        else:
            return ai_reply

    def _extract_express_info(self, user_msg: str, context: str) -> dict:
        info = {}
        import re
        # 寄件地
        from_match = re.search(r'(?:从|寄自|寄件地|发货地|)([\u4e00-\u9fa5]{2,10})(?:到|寄往|寄至|送到|发往)', user_msg)
        if from_match:
            info['from'] = from_match.group(1)
        # 收件地
        to_match = re.search(r'(?:到|寄往|寄至|送到|发往)([\u4e00-\u9fa5]{2,10})', user_msg)
        if to_match:
            info['to'] = to_match.group(1)
        # 重量，支持kg/斤/g/克
        weight_match = re.search(r'(\d+(?:\.\d+)?)(kg|千克|公斤|g|克|斤)', user_msg)
        if weight_match:
            num = float(weight_match.group(1))
            unit = weight_match.group(2)
            if unit in ['斤']:
                num = num * 0.5
                unit = 'kg'
            elif unit in ['g', '克']:
                num = num / 1000
                unit = 'kg'
            info['weight'] = f"{num}{unit}"
        # 物品
        item_match = re.search(r'(寄|快递|邮寄|送|发)([\u4e00-\u9fa5]{2,10})', user_msg)
        if item_match:
            info['item_type'] = item_match.group(2)
        return info

    def _call_ckd(self, info: dict) -> str:
        print(f"[DEBUG] 调用ckd查价: {info}")
        from_province, from_city = ckd.split_province_city(info['from'])
        to_province, to_city = ckd.split_province_city(info['to'])
        if not from_city:
            from_city = self._get_province_capital(from_province)
        if not to_city:
            to_city = self._get_province_capital(to_province)
        goods = info['item_type']
        weight = float(re.sub(r'[^\d.]+', '', info['weight'])) if 'weight' in info else 1
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(
                ckd.get_quote(from_province, from_city, to_province, to_city, goods, weight)
            )
            print(f"[DEBUG] ckd返回: {result}")
            if result.get("code") == 200:
                items = result.get("data", {}).get("Y", [])
                if items:
                    cheapest = min(items, key=lambda x: float(x.get("preOrderFee", 9999)))
                    name = cheapest.get("channelName", "")[:8]
                    total = cheapest.get("preOrderFee", "")
                    return f"{from_province}{from_city}到{to_province}{to_city}寄{goods}{weight}kg，{name}约{total}元"
                else:
                    return "未查到可用快递报价"
            else:
                return f"查价失败：{result.get('msg')}"
        except Exception as e:
            print(f"[DEBUG] ckd查价异常: {e}")
            return f"查价异常：{e}"

    def _get_province_capital(self, province: str) -> str:
        capitals = {
            "北京": "北京", "天津": "天津", "上海": "上海", "重庆": "重庆",
            "河北省": "石家庄", "山西省": "太原", "辽宁省": "沈阳", "吉林省": "长春", "黑龙江省": "哈尔滨",
            "江苏省": "南京", "浙江省": "杭州", "安徽省": "合肥", "福建省": "福州", "江西省": "南昌",
            "山东省": "济南", "河南省": "郑州", "湖北省": "武汉", "湖南省": "长沙", "广东省": "广州",
            "海南省": "海口", "四川省": "成都", "贵州省": "贵阳", "云南省": "昆明", "陕西省": "西安",
            "甘肃省": "兰州", "青海省": "西宁", "台湾省": "台北", "内蒙古自治区": "呼和浩特", "广西壮族自治区": "南宁",
            "西藏自治区": "拉萨", "宁夏回族自治区": "银川", "新疆维吾尔自治区": "乌鲁木齐", "香港特别行政区": "香港", "澳门特别行政区": "澳门"
        }
        for k, v in capitals.items():
            if province.startswith(k.replace("省", "").replace("市", "")) or province == k:
                return v
        return province


class ClassifyAgent(BaseAgent):
    """意图识别Agent"""

    def generate(self, **args) -> str:
        response = super().generate(**args)
        return response


class DefaultAgent(BaseAgent):
    """默认处理Agent"""

    def _call_llm(self, messages: List[Dict], *args) -> str:
        """限制默认回复长度"""
        return self.provider.chat_completion(messages, temperature=0.7)