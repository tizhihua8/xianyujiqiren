"""
模拟闲鱼API，用于本地测试，无需真实登录
"""
import json
import os
import random
import time
from typing import Dict, Any, Optional
from loguru import logger

class MockXianyuApi:
    """模拟闲鱼API，提供商品信息查询等功能"""
    
    def __init__(self):
        """初始化模拟API"""
        self.item_cache = {}  # 商品信息缓存
        self.mock_data_dir = os.path.join(os.path.dirname(__file__), "mock_data")
        
        # 创建mock_data目录（如果不存在）
        os.makedirs(self.mock_data_dir, exist_ok=True)
        
        # 加载预设商品数据
        self._load_preset_items()
        
    def _load_preset_items(self):
        """加载预设商品数据"""
        # 预设一些常用商品类型
        preset_items = {
            # 手机类
            "100000001": {
                "itemId": "100000001",
                "title": "二手iPhone 13 128G 国行正品",
                "desc": "iPhone 13 128G 国行，95新，无拆修，电池健康90%，配件齐全，支持验机",
                "soldPrice": 3999,
                "originalPrice": 5999,
                "category": "手机",
                "brand": "Apple",
                "condition": "95新",
                "location": "上海",
                "seller": {
                    "userId": "2220188410046",
                    "nick": "手机二手优品",
                    "rating": 4.9
                }
            },
            
            # 电脑类
            "100000002": {
                "itemId": "100000002",
                "title": "联想ThinkPad X1 Carbon 2022款",
                "desc": "ThinkPad X1 Carbon 2022款，i7-1260P，16G内存，512G固态，2K屏幕，轻薄商务本，98新",
                "soldPrice": 6500,
                "originalPrice": 12999,
                "category": "笔记本电脑",
                "brand": "联想",
                "condition": "98新",
                "location": "北京",
                "seller": {
                    "userId": "2220188410046",
                    "nick": "电脑数码专营",
                    "rating": 4.8
                }
            },
            
            # 服装类
            "100000003": {
                "itemId": "100000003",
                "title": "Nike Air Jordan 1 AJ1 黑红脚趾",
                "desc": "Nike Air Jordan 1 黑红脚趾，42码，全新正品，带盒带票",
                "soldPrice": 1200,
                "originalPrice": 1499,
                "category": "运动鞋",
                "brand": "Nike",
                "condition": "全新",
                "location": "广州",
                "seller": {
                    "userId": "2220188410046",
                    "nick": "球鞋潮牌",
                    "rating": 4.7
                }
            },
            
            # 家电类
            "100000004": {
                "itemId": "100000004",
                "title": "戴森吸尘器V11 家用无线手持",
                "desc": "戴森吸尘器V11，9成新，电池续航良好，功能完好，配件齐全",
                "soldPrice": 2200,
                "originalPrice": 4500,
                "category": "家用电器",
                "brand": "戴森",
                "condition": "9成新",
                "location": "深圳",
                "seller": {
                    "userId": "2220188410046",
                    "nick": "家电优品",
                    "rating": 4.8
                }
            },
            
            # 箱包类
            "100000005": {
                "itemId": "100000005",
                "title": "LV老花单肩包 M40712 正品",
                "desc": "LV老花单肩包，型号M40712，9成新，尺寸25*18*9cm，配专柜小票和防尘袋",
                "soldPrice": 8500,
                "originalPrice": 14500,
                "category": "奢侈品",
                "brand": "Louis Vuitton",
                "condition": "9成新",
                "location": "上海",
                "seller": {
                    "userId": "2220188410046",
                    "nick": "奢品优选",
                    "rating": 4.9
                }
            },
            
            # 皮包修复类
            "795486159750": {
                "itemId": "795486159750",
                "title": "皮包修复保养皮带肩带改短复刻。。。。旧物焕然一新！",
                "desc": "专业皮包修复保养服务，包括皮带肩带改短、皮面翻新、五金件更换等。多年经验，让您的旧物焕然一新！",
                "soldPrice": 80,
                "originalPrice": 100,
                "category": "服务",
                "brand": "专业皮具修复",
                "condition": "服务类",
                "location": "广州",
                "seller": {
                    "userId": "2220188410046",
                    "nick": "皮具修复专家",
                    "rating": 4.9
                }
            }
        }
        
        # 将预设商品添加到缓存
        for item_id, item_data in preset_items.items():
            self.item_cache[item_id] = item_data
            
        logger.info(f"已加载{len(preset_items)}个预设商品数据")
    
    async def get_item_info(self, item_id: str, retry_count: int = 0) -> Dict[str, Any]:
        """
        获取商品信息
        
        Args:
            item_id: 商品ID
            retry_count: 重试次数（模拟真实API）
            
        Returns:
            Dict: 商品信息
        """
        # 模拟网络延迟
        await self._simulate_delay(0.2, 0.8)
        
        # 检查缓存中是否有该商品
        if item_id in self.item_cache:
            logger.info(f"从缓存获取商品信息: {item_id}")
            return self._format_item_response(self.item_cache[item_id])
        
        # 检查是否有自定义商品文件
        custom_item_file = os.path.join(self.mock_data_dir, f"item_{item_id}.json")
        if os.path.exists(custom_item_file):
            try:
                with open(custom_item_file, 'r', encoding='utf-8') as f:
                    item_data = json.load(f)
                    self.item_cache[item_id] = item_data
                    logger.info(f"从自定义文件加载商品信息: {item_id}")
                    return self._format_item_response(item_data)
            except Exception as e:
                logger.error(f"加载自定义商品信息失败: {e}")
        
        # 如果没有找到商品，生成一个随机商品
        if retry_count < 1:  # 模拟重试逻辑
            logger.warning(f"商品不存在，生成随机商品: {item_id}")
            random_item = self._generate_random_item(item_id)
            self.item_cache[item_id] = random_item
            return self._format_item_response(random_item)
        else:
            # 模拟API错误
            logger.error(f"获取商品信息失败: {item_id}")
            return {"error": "商品不存在", "code": 404}
    
    def _format_item_response(self, item_data: Dict[str, Any]) -> Dict[str, Any]:
        """格式化商品信息响应，模拟闲鱼API格式"""
        return {
            "api": "mtop.taobao.idle.pc.detail",
            "data": {
                "itemDO": item_data
            },
            "ret": ["SUCCESS::调用成功"],
            "v": "1.0"
        }
    
    def _generate_random_item(self, item_id: str) -> Dict[str, Any]:
        """生成随机商品信息"""
        categories = ["手机", "电脑", "服装", "家电", "箱包", "数码", "图书", "运动", "美妆", "玩具"]
        brands = ["Apple", "三星", "华为", "小米", "联想", "戴尔", "耐克", "阿迪达斯", "无印良品", "优衣库"]
        conditions = ["全新", "99新", "95新", "9成新", "8成新", "7成新", "可用"]
        locations = ["北京", "上海", "广州", "深圳", "杭州", "成都", "重庆", "武汉", "南京", "西安"]
        
        category = random.choice(categories)
        brand = random.choice(brands)
        condition = random.choice(conditions)
        location = random.choice(locations)
        
        # 根据类别生成标题和描述
        title_templates = {
            "手机": [f"{brand}手机二手", f"二手{brand}手机", f"{brand}旗舰机"],
            "电脑": [f"{brand}笔记本电脑", f"二手{brand}电脑", f"{brand}台式机"],
            "服装": [f"{brand}服装", f"{brand}外套", f"{brand}T恤"],
            "家电": [f"{brand}家电", f"{brand}电视", f"{brand}冰箱"],
            "箱包": [f"{brand}包包", f"{brand}背包", f"{brand}钱包"],
            "数码": [f"{brand}数码产品", f"{brand}相机", f"{brand}耳机"],
            "图书": ["二手书籍", "教材", "小说"],
            "运动": [f"{brand}运动鞋", f"{brand}运动服", "健身器材"],
            "美妆": [f"{brand}化妆品", f"{brand}护肤品", "彩妆套装"],
            "玩具": ["玩具", "模型", "手办"]
        }
        
        desc_templates = {
            "手机": [f"{brand}手机，{condition}，无拆修，功能正常，电池健康度良好"],
            "电脑": [f"{brand}电脑，{condition}，i5处理器，8G内存，256G固态，性能良好"],
            "服装": [f"{brand}{category}，{condition}，尺码L，版型好看，面料舒适"],
            "家电": [f"{brand}{category}，{condition}，功能正常，无明显磕碰"],
            "箱包": [f"{brand}包包，{condition}，尺寸适中，容量大，做工精细"],
            "数码": [f"{brand}数码产品，{condition}，功能完好，外观干净"],
            "图书": ["二手书籍，品相良好，无缺页，无笔记"],
            "运动": [f"{brand}运动装备，{condition}，尺码合适，舒适耐穿"],
            "美妆": [f"{brand}化妆品，{condition}，保质期内，效果好"],
            "玩具": ["玩具，品相良好，适合收藏或把玩"]
        }
        
        title = random.choice(title_templates.get(category, [f"{brand}{category}"])) + f" {condition}"
        desc = random.choice(desc_templates.get(category, [f"{brand}{category}，{condition}"]))
        
        # 随机价格
        price_ranges = {
            "手机": (500, 5000),
            "电脑": (1000, 8000),
            "服装": (50, 500),
            "家电": (200, 2000),
            "箱包": (100, 1000),
            "数码": (200, 3000),
            "图书": (10, 100),
            "运动": (100, 800),
            "美妆": (50, 500),
            "玩具": (20, 300)
        }
        
        price_range = price_ranges.get(category, (50, 1000))
        sold_price = random.randint(price_range[0], price_range[1])
        original_price = int(sold_price * random.uniform(1.2, 1.8))
        
        return {
            "itemId": item_id,
            "title": title,
            "desc": desc,
            "soldPrice": sold_price,
            "originalPrice": original_price,
            "category": category,
            "brand": brand,
            "condition": condition,
            "location": location,
            "seller": {
                "userId": "2220188410046",
                "nick": "闲鱼卖家",
                "rating": round(random.uniform(4.0, 5.0), 1)
            }
        }
    
    def save_custom_item(self, item_id: str, item_data: Dict[str, Any]) -> bool:
        """
        保存自定义商品信息
        
        Args:
            item_id: 商品ID
            item_data: 商品信息
            
        Returns:
            bool: 是否保存成功
        """
        try:
            # 确保必要字段存在
            required_fields = ["title", "desc", "soldPrice"]
            for field in required_fields:
                if field not in item_data:
                    logger.error(f"保存自定义商品失败: 缺少必要字段 {field}")
                    return False
            
            # 添加商品ID
            item_data["itemId"] = item_id
            
            # 保存到缓存
            self.item_cache[item_id] = item_data
            
            # 保存到文件
            custom_item_file = os.path.join(self.mock_data_dir, f"item_{item_id}.json")
            with open(custom_item_file, 'w', encoding='utf-8') as f:
                json.dump(item_data, f, ensure_ascii=False, indent=2)
            
            logger.info(f"已保存自定义商品: {item_id}")
            return True
            
        except Exception as e:
            logger.error(f"保存自定义商品失败: {e}")
            return False
    
    async def _simulate_delay(self, min_delay: float = 0.1, max_delay: float = 0.5):
        """模拟网络延迟"""
        import asyncio
        delay = random.uniform(min_delay, max_delay)
        await asyncio.sleep(delay) 